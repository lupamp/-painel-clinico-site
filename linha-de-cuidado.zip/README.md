# Painel Clínico APS — versão refatorada

Esta pasta já está pronta para abrir no Visual Studio Code e carregar como extensão no Chrome/Edge.

## O que mudou
- O antigo `content.js` foi dividido em arquivos menores:
  - `src/core/constants.js` → seletores, mensagens e códigos ISF
  - `src/core/data.js` → tabelas clínicas e dados fixos
  - `src/core/utils.js` → funções reutilizáveis
  - `src/core/calculators.js` → cálculos e gráficos
  - `src/ui/sidebar-template.js` → HTML da sidebar
  - `src/bridge/frame-bridge.js` → comunicação com a tela do Sissonline
  - `src/main.js` → interface principal e eventos
- Removida a duplicação do cálculo PREVENT
- Validação de origem adicionada nos listeners de mensagens
- `manifest.json` mais restrito
- Estrutura mais fácil de manter no longo prazo

## Como instalar no navegador
1. Extraia o arquivo ZIP.
2. Abra o Chrome ou Edge.
3. Entre em `chrome://extensions` ou `edge://extensions`.
4. Ative o **Modo do desenvolvedor**.
5. Clique em **Carregar sem compactação**.
6. Escolha esta pasta.

## Como editar no Visual Studio Code
1. Abra esta pasta inteira no VS Code.
2. Edite o arquivo desejado.
3. Salve.
4. Volte na página de extensões do navegador e clique em **Atualizar/Recarregar** na extensão.

## Arquivos mais importantes para manutenção
- Alterar regras clínicas: `src/main.js` e `src/core/calculators.js`
- Alterar seletores do Sissonline: `src/core/constants.js`
- Alterar textos fixos/curvas/tabelas: `src/core/data.js`
- Alterar layout da sidebar: `src/ui/sidebar-template.js` e `sidebar.css`

## Observação
Esta refatoração foi feita para melhorar a manutenção sem mudar o propósito clínico da extensão. Mesmo assim, como a extensão depende do HTML do Sissonline, qualquer mudança futura no site pode exigir ajuste nos seletores.

## Novidade da versão 3.0.2
- O painel de gestante ganhou o checkbox **“Testes rápidos realizados na consulta”**.
- Quando ele é marcado, o botão **Lançar Procedimentos (Enfermagem)** inclui automaticamente os 4 códigos de testes rápidos da gestante.


## Atualização 3.2.0
- Corrigido o ponto preto nas curvas antropométricas para aparecer também quando o valor fica fora da faixa visual padrão.
- Curvas de Peso/Idade, Altura/Idade e IMC/Idade estendidas até 17 anos e 11 meses.
- Exportação da criança renomeada para “AVALIAÇÃO ANTROPOMÉTRICA”.
