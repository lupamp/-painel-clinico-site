(() => {
  const App = (window.PainelAPS = window.PainelAPS || {});
  const { IDS, ISF_CODES, RAPID_TEST_PROCEDURES } = App.constants;
  const {
    PUERI_DATA,
    PRENATAL_DATA,
    PESO_M,
    ALT_M,
    IMC_M,
    PC_M,
    PESO_F,
    ALT_F,
    IMC_F,
    PC_F,
    PESO_M_EXT,
    ALT_M_EXT,
    IMC_M_EXT,
    PESO_F_EXT,
    ALT_F_EXT,
    IMC_F_EXT,
  } = App.data;
  const { getKeys, interp, calcZScore, getZClass, drawChart, calcularRiscoAHA, obterMetasPrevent } = App.calculators;
  const { broadcastMessage, escapeHtml, findElementDeep, getFieldValue, isTrustedSissonMessage, parseBRNumber, registrarAuditoria, verificarSeletoresCriticos } = App.utils;
  const adultoTexts = App.adultoTexts || {};

  if (window !== window.top) return;
  if (document.getElementById(IDS.sidebar)) return;

  // ── G04 FIX: Healthcheck de seletores (só dentro do prontuário) ──
  setTimeout(() => {
    const estaNoProntuario = /prontuarioeletronico\/prontuarioeletronico/i.test(window.location.href);
    if (estaNoProntuario) {
      const { SELECTORS } = App.constants;
      const ausentes = verificarSeletoresCriticos(SELECTORS);
      if (ausentes.length > 0) {
        console.warn('[PainelAPS] Seletores não encontrados no prontuário:', ausentes);
        registrarAuditoria('HEALTHCHECK_ALERTA', { seletoresAusentes: ausentes });
      }
    }
    registrarAuditoria('EXTENSAO_INICIADA', { versao: '4.2.0', pagina: window.location.pathname });
  }, 3000);

  // ── S04 FIX: Modal de confirmação antes de escrita no prontuário ──
  function confirmarAcao(titulo, detalhe) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:999999;display:flex;align-items:center;justify-content:center;';
      const box = document.createElement('div');
      box.style.cssText = 'background:#fff;border-radius:12px;padding:20px 24px;max-width:460px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.25);font-family:system-ui,sans-serif;';
      const h = document.createElement('h3');
      h.textContent = titulo;
      h.style.cssText = 'margin:0 0 8px;font-size:15px;color:#1e293b;';
      const p = document.createElement('p');
      p.style.cssText = 'margin:0 0 16px;font-size:12px;color:#475569;white-space:pre-wrap;max-height:200px;overflow-y:auto;line-height:1.5;';
      p.textContent = detalhe;
      const btns = document.createElement('div');
      btns.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;';
      const btnCancel = document.createElement('button');
      btnCancel.textContent = '✕ Cancelar';
      btnCancel.style.cssText = 'padding:8px 16px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;color:#475569;cursor:pointer;font-size:12px;';
      const btnOk = document.createElement('button');
      btnOk.textContent = '✓ Confirmar e Inserir';
      btnOk.style.cssText = 'padding:8px 16px;border:none;border-radius:6px;background:#2563eb;color:#fff;cursor:pointer;font-size:12px;font-weight:600;';
      btns.appendChild(btnCancel);
      btns.appendChild(btnOk);
      box.appendChild(h);
      box.appendChild(p);
      box.appendChild(btns);
      overlay.appendChild(box);
      document.body.appendChild(overlay);
      btnOk.addEventListener('click', () => { overlay.remove(); resolve(true); });
      btnCancel.addEventListener('click', () => { overlay.remove(); resolve(false); });
      overlay.addEventListener('click', (e) => { if (e.target === overlay) { overlay.remove(); resolve(false); } });
    });
  }

  // Wrapper: envia mensagem de conduta SÓ após confirmação do profissional
  async function enviarCondutaComConfirmacao(msg, resumo) {
    const ok = await confirmarAcao('Inserir no prontuário?', resumo || msg.texto || '(sem texto)');
    if (!ok) return;
    enviarParaFrames(window, msg);
  }

  // Wrapper: envia lançamento ISF SÓ após confirmação
  async function enviarISFComConfirmacao(payload, label) {
    const codigos = (payload.procedimentos || []).map(c => String(c).replace(/\D/g, '') || c).join(', ');
    const ok = await confirmarAcao(
      'Lançar procedimentos?',
      `${label || 'Procedimentos'}:\n${codigos}\n\nOs códigos acima serão marcados automaticamente na aba de produção ambulatorial.`
    );
    if (!ok) return false;
    enviarParaFrames(window, { type: 'ISF_LANCAR_PROCEDIMENTOS', payload });
    return true;
  }

  const sidebar = document.createElement('div');
  sidebar.id = IDS.sidebar;
  sidebar.innerHTML = App.templates.getSidebarHtml();
  document.body.appendChild(sidebar);

  const toggle = document.createElement('button');
  toggle.id = IDS.toggle;
  toggle.title = 'Ferramentas Clínicas APS';
  try {
    const iconUrl = chrome.runtime.getURL('icon.png');
    toggle.innerHTML = `<img src="${iconUrl}" style="width: 32px; height: 32px; display: block; margin: auto; pointer-events: none; user-select: none;">`;
  } catch (error) {
    toggle.textContent = '🧰';
  }
  document.body.appendChild(toggle);

  toggle.addEventListener('click', () => { sidebar.classList.toggle('open'); });
  const closeButton = document.getElementById('clinic-close');
  if (closeButton) closeButton.addEventListener('click', () => { sidebar.classList.remove('open'); });

  function enviarParaFrames(janela, msg) {
    broadcastMessage(janela, msg);
  }


  function normalizarDataParaInput(valor) {
    if (!valor) return '';
    const texto = String(valor).trim();

    if (/^\d{4}-\d{2}-\d{2}$/.test(texto)) return texto;

    let match = texto.match(/^(\d{2})[\/.-](\d{2})[\/.-](\d{4})$/);
    if (match) return `${match[3]}-${match[2]}-${match[1]}`;

    match = texto.match(/^(\d{4})[\/.-](\d{2})[\/.-](\d{2})$/);
    if (match) return `${match[1]}-${match[2]}-${match[3]}`;

    return '';
  }

  function obterDUMNormalizadaDoPainel(payload) {
    if (!payload) return '';
    return normalizarDataParaInput(payload.dum || payload.DUM || payload.dataUltimaMenstruacao || payload.data_ultima_menstruacao || '');
  }

    // ── Lógica de Navegação ──
    const panes = document.querySelectorAll('.clinic-tab-pane');
    const cards = document.querySelectorAll('.dash-card, .lc-card');
    const btnsVoltar = document.querySelectorAll('.btn-voltar-menu');

    cards.forEach(card => {
      card.addEventListener('click', () => {
        panes.forEach(p => p.classList.remove('active'));
        const targetId = card.getAttribute('data-target');
        if(targetId) {
            document.getElementById(targetId).classList.add('active');
            if (targetId === 'pane-prenatal') {
                enviarParaFrames(window, { type: 'PN_PEDIR_DADOS' });
            }
            if (targetId === 'pane-preventivo' || targetId === 'pane-adulto-clinica' || targetId === 'pane-prev') {
                enviarParaFrames(window, { type: 'PREVENT_PEDIR_DADOS' });
            }
        }
      });
    });

    btnsVoltar.forEach(btn => {
      btn.addEventListener('click', (e) => {
        panes.forEach(p => p.classList.remove('active'));
        const currentPane = e.target.closest('.clinic-tab-pane').id;
        if (currentPane === 'pane-prenatal' || currentPane === 'pane-preventivo' || currentPane === 'pane-tr-parceiro') { 
            document.getElementById('pane-mulher').classList.add('active'); 
        } else if (currentPane === 'pane-prev' || currentPane === 'pane-ves' || currentPane === 'pane-adulto-clinica') { 
            document.getElementById('pane-adulto').classList.add('active'); 
        } else { 
            document.getElementById('pane-home').classList.add('active'); 
        }
        const step1 = document.getElementById('isf-step-1');
        const step2 = document.getElementById('isf-step-2');
        if(step1) step1.style.display = 'block';
        if(step2) step2.style.display = 'none';
        const statusDiv = document.getElementById('isf-status');
        if(statusDiv) statusDiv.innerHTML = "Pronto para lançar.";
      });
    });
  const btnPerfilMedico = document.getElementById('btn-perfil-medico');
    const btnPerfilEnfermagem = document.getElementById('btn-perfil-enfermagem');
    const btnTrocarPerfil = document.getElementById('btn-trocar-perfil');

    if (btnPerfilMedico) btnPerfilMedico.addEventListener('click', () => carregarPerfilISF('medico'));
    if (btnPerfilEnfermagem) btnPerfilEnfermagem.addEventListener('click', () => carregarPerfilISF('enfermagem'));
  
    if (btnTrocarPerfil) {
      btnTrocarPerfil.addEventListener('click', () => {
        document.getElementById('isf-step-2').style.display = 'none';
        document.getElementById('isf-step-1').style.display = 'block';
        document.getElementById('isf-status').innerHTML = "Pronto para lançar.";
      });
    }

    function carregarPerfilISF(perfil) {
        document.getElementById('isf-step-1').style.display = 'none';
        document.getElementById('isf-step-2').style.display = 'block';
        const title = document.getElementById('isf-perfil-title');
        title.textContent = perfil === 'medico' ? '👨‍⚕️ Perfil: Médico' : '👩‍⚕️ Perfil: Enfermagem';
        const container = document.getElementById('isf-buttons-container');
        container.innerHTML = '';
        const dados = ISF_CODES[perfil];
        for (const [chave, obj] of Object.entries(dados)) {
            const btn = document.createElement('button');
            btn.className = 'isf-btn';
            btn.textContent = obj.label;
            btn.onclick = async () => {
                const statusDiv = document.getElementById('isf-status');
                const ok = await enviarISFComConfirmacao(obj, obj.label);
                if (ok) {
                    statusDiv.innerHTML = `<span style="color:#0284c7;">⏳ Processando. Aguarde...</span>`;
                }
            };
            container.appendChild(btn);
        }
    }

    window.addEventListener('message', (event) => {
      if (!isTrustedSissonMessage(event)) return;
      if (event.data && event.data.type === 'ISF_RESPOSTA_LANCAMENTO') {
        const statusDiv = document.getElementById('isf-status');
        const enc = event.data.encontrados;
        const nao = event.data.naoEncontrados;
        if (nao.length === 0) {
          if(statusDiv) statusDiv.innerHTML = `<span style="color: #059669;">✅ Procedimentos lançados com sucesso!</span>`;
        } else {
          if(statusDiv) statusDiv.innerHTML = `<span style="color: #d97706;">⚠️ Marcados: <b>${enc.length}</b>. Faltaram: <b>${nao.length}</b>.<br><br>👉 Tentei inserir automaticamente o código <b>${escapeHtml(nao[0])}</b>.</span>`;
        }
      }
    });

    const elPueriIdade = document.getElementById('pueri-idade');
    const ccGrid = document.querySelector('.cc-grid');
    const ccBtns = document.querySelector('.cc-btns');
    const pueriRes = document.getElementById('pueri-resultado');
  
    if(ccGrid && ccBtns && elPueriIdade && pueriRes) {
      ccGrid.style.setProperty('display', 'none', 'important');
      ccBtns.style.setProperty('display', 'none', 'important');
      elPueriIdade.addEventListener('change', function() {
        const val = this.value;
        if(val !== "") {
          pueriRes.style.display = 'block';
          if (val === '>2a') {
            document.getElementById('pueri-titulo').textContent = "Consulta Criança Maior (> 2 anos)";
            document.getElementById('pueri-dnpm').textContent = "Marcos principais estabelecidos. Avaliar desenvolvimento geral, coordenação motora, linguagem (formação de frases) e socialização/brincar interativo.";
            document.getElementById('pueri-alerta').textContent = "Regressão de marcos adquiridos, atraso grave de fala, ou dificuldades severas de interação social.";
            document.getElementById('pueri-vacina').textContent = "Checar caderneta para reforços aos 4 anos (DTP, VIP, Varicela, Febre Amarela).";
            document.getElementById('pueri-dieta').textContent = "Dieta da família. Reforçar ingestão de in natura, mínimo de ultraprocessados e controle rigoroso de tempo de telas.";
            document.getElementById('pueri-conduta').textContent = "Cálculo focado nos parâmetros antropométricos da OMS (Z-Score abaixo).";
          } else {
            const dados = PUERI_DATA[val];
            document.getElementById('pueri-titulo').textContent = dados.titulo;
            document.getElementById('pueri-dnpm').textContent = dados.dnpm;
            document.getElementById('pueri-alerta').textContent = dados.alerta;
            document.getElementById('pueri-vacina').textContent = dados.vacina;
            document.getElementById('pueri-dieta').textContent = dados.dieta;
            document.getElementById('pueri-conduta').textContent = dados.conduta;
          }
          ccGrid.style.setProperty('display', 'grid', 'important');
          ccBtns.style.setProperty('display', 'flex', 'important');
        } else {
          pueriRes.style.display = 'none';
          ccGrid.style.setProperty('display', 'none', 'important');
          ccBtns.style.setProperty('display', 'none', 'important');
        }
      });
    }

    window.addEventListener('message', (event) => {
      if (!isTrustedSissonMessage(event)) return;
      if (event.data && event.data.type === 'PREVENT_RESPOSTA_DADOS') {
        const dados = event.data.payload; 
        let encontrados = 0;
      
        if (dados.idade) { 
            const nums = dados.idade.match(/[\d,.]+/); 
            if (nums) { 
                const v = nums[0].replace(',', '.');
                if(document.getElementById('prev-idade')) document.getElementById('prev-idade').value = v; 
                if(document.getElementById('adl-prev-idade')) document.getElementById('adl-prev-idade').value = v;
                if(document.getElementById('prev-idade-mulher')) document.getElementById('prev-idade-mulher').value = v;
                encontrados++; 
            } 
        }
      
        if (dados.sexo) { 
            let s = dados.sexo.toUpperCase(); 
            if (s.startsWith('M') || s.startsWith('F')) {
                const sf = s.startsWith('M') ? 'M' : 'F';
                if(document.getElementById('prev-sexo')) document.getElementById('prev-sexo').value = sf; 
                if(document.getElementById('adl-prev-sexo')) document.getElementById('adl-prev-sexo').value = sf;
                encontrados++; 
            }
        }
      
        if (dados.pas) { 
            const nums = dados.pas.match(/[\d,.]+/); 
            if (nums) { 
                const v = nums[0].replace(',', '.');
                if(document.getElementById('prev-pas')) document.getElementById('prev-pas').value = v; 
                if(document.getElementById('adl-prev-pas')) document.getElementById('adl-prev-pas').value = v;
                encontrados++; 
            } 
        }
      
        if (dados.textoExames) {
          const matchCT = dados.textoExames.match(/(?:colesterol total|ct|col\.\s*total)[\s=:-]+(\d{2,3}(?:[.,]\d+)?)/i); 
          if (matchCT) { 
              const v = matchCT[1].replace(',', '.');
              if(document.getElementById('prev-colTotal')) document.getElementById('prev-colTotal').value = v; 
              if(document.getElementById('adl-prev-col')) document.getElementById('adl-prev-col').value = v;
              encontrados++; 
          }
        
          const matchHDL = dados.textoExames.match(/(?:hdl)[\s=:-]+(\d{2,3}(?:[.,]\d+)?)/i); 
          if (matchHDL) { 
              const v = matchHDL[1].replace(',', '.');
              if(document.getElementById('prev-hdl')) document.getElementById('prev-hdl').value = v; 
              if(document.getElementById('adl-prev-hdl')) document.getElementById('adl-prev-hdl').value = v;
              encontrados++; 
          }
        
          const matchTFG = dados.textoExames.match(/(?:tfg|clcr|filtração|filtracao|clearance)[\s=:-]+(\d{2,3}(?:[.,]\d+)?)/i); 
          if (matchTFG) { 
              const v = matchTFG[1].replace(',', '.');
              if(document.getElementById('prev-tfg')) document.getElementById('prev-tfg').value = v;
              if(document.getElementById('adl-prev-tfg')) document.getElementById('adl-prev-tfg').value = v; 
              encontrados++; 
          }
        }
      
        const msgAdulto = document.getElementById('adl-auto-msg');
        if(msgAdulto) { 
            msgAdulto.textContent = `✓ ${encontrados} dado(s) preenchido(s)!`; 
            setTimeout(() => msgAdulto.textContent = '', 3000); 
        }
      
        const msgPrev = document.getElementById('prevent-auto-msg');
        if (msgPrev) { 
            msgPrev.textContent = `✓ ${encontrados} dado(s) preenchido(s)!`; 
            msgPrev.style.color = '#4ade80'; 
            setTimeout(() => msgPrev.textContent = '', 3000); 
        }
      }
    
      if (event.data && event.data.type === 'PN_RESPOSTA_DADOS') {
        const dumNormalizada = obterDUMNormalizadaDoPainel(event.data.payload);
        const inputDum = document.getElementById('pn-dum');
        if (dumNormalizada && inputDum && !inputDum.value) {
          inputDum.value = dumNormalizada;
          setTimeout(() => { document.getElementById('pn-calc-btn').click(); }, 100);
        }
      }
    });

    // ── Lógica Pré-Natal ──
    const btnCalcPN = document.getElementById('pn-calc-btn');
    if (btnCalcPN) {
        btnCalcPN.addEventListener('click', () => {
          const dumInput = document.getElementById('pn-dum');
          const dumStr = normalizarDataParaInput(dumInput.value);
          if (!dumStr) { alert("Informe a Data da Última Menstruação (DUM)."); return; }
          if (dumInput.value !== dumStr) dumInput.value = dumStr;

          const [year, month, day] = dumStr.split('-').map(Number);
          const dum = new Date(year, month - 1, day);
          if (Number.isNaN(dum.getTime())) { alert("Não foi possível interpretar a DUM informada."); return; }

          const today = new Date();
        
          const diffTime = today - dum;
          if (diffTime < 0) { alert("A DUM não pode ser no futuro."); return; }
        
          const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24)); 
          const igSemanas = Math.floor(diffDays / 7); 
          const igDias = diffDays % 7;
        
          const dpp = new Date(dum); 
          dpp.setDate(dpp.getDate() + 280); 
          const dppFormatada = dpp.toLocaleDateString('pt-BR');
        
          document.getElementById('pn-ig-valor').textContent = `${igSemanas} sem e ${igDias} dias`; 
          document.getElementById('pn-dpp-valor').textContent = `DPP: ${dppFormatada}`;

          let dadosTrim; 
          if (igSemanas < 14) { 
              dadosTrim = PRENATAL_DATA.trim1; 
          } else if (igSemanas < 28) { 
              dadosTrim = PRENATAL_DATA.trim2; 
          } else { 
              dadosTrim = PRENATAL_DATA.trim3; 
          }
        
          document.getElementById('pn-trim-titulo').textContent = dadosTrim.titulo; 
          document.getElementById('pn-clinica').textContent = dadosTrim.clinica; 
          document.getElementById('pn-exames').textContent = dadosTrim.exames; 
          document.getElementById('pn-conduta').textContent = dadosTrim.conduta;
          document.getElementById('pn-resultado').style.display = 'block'; 

          const checkboxTestesRapidos = document.getElementById('pn-testes-rapidos');
          const incluirTestesRapidos = Boolean(checkboxTestesRapidos && checkboxTestesRapidos.checked);
          const observacaoTestes = incluirTestesRapidos ? '\n- Testes rápidos realizados na consulta: HBsAg, HIV, Sífilis e Hepatite C.' : '';
          const textoExportacao = `${dadosTrim.conduta}${observacaoTestes}`;
        
          const btnExportPN = document.getElementById('pn-export-btn');
          if(btnExportPN) {
              btnExportPN.dataset.texto = textoExportacao;
          }
        });
    }

    const btnExportPN = document.getElementById('pn-export-btn');
    if(btnExportPN) {
        btnExportPN.addEventListener('click', async (e) => {
            await enviarCondutaComConfirmacao({ type: 'PN_INSERIR_CONDUTA', texto: e.target.dataset.texto }, e.target.dataset.texto);
        });
    }

    function montarPayloadGestanteEnfermagem() {
        const base = ISF_CODES.enfermagem.gestante || {};
        const checkboxTestesRapidos = document.getElementById('pn-testes-rapidos');
        const incluirTestesRapidos = Boolean(checkboxTestesRapidos && checkboxTestesRapidos.checked);
        const procedimentosBase = Array.isArray(base.procedimentos) ? [...base.procedimentos] : [];
        const procedimentosExtras = incluirTestesRapidos ? (RAPID_TEST_PROCEDURES?.gestante || []) : [];
        const procedimentos = [...new Set([...procedimentosBase, ...procedimentosExtras])];

        return {
            ...base,
            procedimentos,
        };
    }

    const btnPnIsfMed = document.getElementById('pn-isf-medico');
    if (btnPnIsfMed) {
        btnPnIsfMed.addEventListener('click', async () => {
            const btnOriginal = btnPnIsfMed.textContent;
            const ok = await enviarISFComConfirmacao(ISF_CODES.medico.gestante, '🤰 Gestante (Médico)');
            if (ok) { btnPnIsfMed.textContent = '⏳ Lançando...'; setTimeout(() => btnPnIsfMed.textContent = btnOriginal, 2000); }
        });
    }

    const btnPnIsfEnf = document.getElementById('pn-isf-enfermagem');
    if (btnPnIsfEnf) {
        btnPnIsfEnf.addEventListener('click', async () => {
            const btnOriginal = btnPnIsfEnf.textContent;
            const checkboxTestesRapidos = document.getElementById('pn-testes-rapidos');
            const incluirTestesRapidos = Boolean(checkboxTestesRapidos && checkboxTestesRapidos.checked);
            const payload = montarPayloadGestanteEnfermagem();
            const ok = await enviarISFComConfirmacao(payload, incluirTestesRapidos ? '🤰 Gestante (Enfermagem + Testes)' : '🤰 Gestante (Enfermagem)');
            if (ok) { btnPnIsfEnf.textContent = incluirTestesRapidos ? '⏳ Lançando enfermagem + testes...' : '⏳ Lançando...'; setTimeout(() => btnPnIsfEnf.textContent = btnOriginal, 2500); }
        });
    }

    // ── Lógica Preventivo (Câncer de Colo) ──
    const btnGerarPrev = document.getElementById('btn-gerar-prev');
    if (btnGerarPrev) {
        btnGerarPrev.addEventListener('click', () => {
            const idade = parseInt(document.getElementById('prev-idade-mulher').value);
            const hist = document.getElementById('prev-hist-pap').value;
            const queixas = document.getElementById('prev-queixas').checked;
            const coloAlt = document.getElementById('prev-colo-alt').checked;
            const resultado = document.getElementById('prev-resultado-pap').value;

            if (isNaN(idade)) { alert("Informe a idade da paciente."); return; }

            let conduta = "";
            let seguimento = "";

            if (idade < 25) {
                conduta = "Paciente menor de 25 anos. Conforme diretriz do MS, o rastreio não é indicado (risco de sobrediagnóstico e sobretratamento de lesões transitórias). Exame não recomendado, exceto se indicação clínica específica.";
            } else if (idade > 64) {
                conduta = "Paciente maior de 64 anos. Conforme diretriz do MS, se tiver 2 exames negativos consecutivos nos últimos 5 anos, pode haver interrupção do rastreio.";
            } else {
                if (resultado === 'normal') {
                    if (hist === "1") seguimento = "Repetir o exame em 1 ano.";
                    else if (hist === "2") seguimento = "Após 2 exames normais consecutivos, repetir a cada 3 anos.";
                    else seguimento = "Manter rotina de rastreio a cada 3 anos.";
                    conduta = `Citopatológico Negativo para malignidade.\n- Seguimento: ${seguimento}`;
                } else if (resultado === 'ascus') {
                    if (idade < 25) seguimento = "Repetir em 3 anos.";
                    else if (idade >= 25 && idade <= 29) seguimento = "Repetir em 1 ano.";
                    else seguimento = "Repetir em 6 meses.";
                    conduta = `Resultado: ASC-US.\n- Seguimento: ${seguimento}`;
                } else if (resultado === 'lsil') {
                    if (idade < 25) seguimento = "Repetir em 3 anos.";
                    else seguimento = "Repetir em 6 meses.";
                    conduta = `Resultado: LSIL.\n- Seguimento: ${seguimento}`;
                } else if (resultado === 'asch' || resultado === 'hsil' || resultado === 'agc') {
                    conduta = `Resultado: ${resultado.toUpperCase()}.\n- Seguimento: Encaminhar para COLPOSCOPIA.`;
                }
            }
            const textoVisualizacao = conduta;
            const textoExportacao = `》DIRETRIZ MS - RASTREAMENTO DO CÂNCER DO COLO DO ÚTERO
${conduta}`;
          
            document.getElementById('prev-res-conduta').textContent = textoVisualizacao;
            document.getElementById('prev-resultado-view').style.display = 'block';

            const btnExport = document.getElementById('prev-export-btn');
            if (btnExport) btnExport.dataset.texto = textoExportacao;
        });
    }

    const btnExportPrev = document.getElementById('prev-export-btn');
    if(btnExportPrev) {
        btnExportPrev.addEventListener('click', async (e) => {
            await enviarCondutaComConfirmacao({ type: 'PAP_INSERIR_CONDUTA', texto: e.target.dataset.texto }, e.target.dataset.texto);
        });
    }

    const btnPrevIsfPap = document.getElementById('prev-isf-pap');
    if (btnPrevIsfPap) {
        btnPrevIsfPap.addEventListener('click', async () => {
            const btnOriginal = btnPrevIsfPap.textContent;
            const ok = await enviarISFComConfirmacao(ISF_CODES.enfermagem.mulher, '🌸 Rastreamento CA colo uterino');
            if (ok) { btnPrevIsfPap.textContent = '⏳ Lançando...'; setTimeout(() => btnPrevIsfPap.textContent = btnOriginal, 2000); }
        });
    }

    const btnTrParceiro = document.getElementById('tr-parceiro-isf-btn');
    if (btnTrParceiro) {
        btnTrParceiro.addEventListener('click', async () => {
            const btnOriginal = btnTrParceiro.textContent;
            const payload = {
                label: '🤝 TR Parceiro',
                procedimentos: RAPID_TEST_PROCEDURES?.parceiroGestante || [],
            };
            const ok = await enviarISFComConfirmacao(payload, '🤝 TR Parceiro Gestante');
            if (ok) { btnTrParceiro.textContent = '⏳ Lançando...'; setTimeout(() => btnTrParceiro.textContent = btnOriginal, 2200); }
        });
    }

    // ── Lógica Puericultura Automática ──
    const btnPueriIniciarAuto = document.getElementById('btn-pueri-iniciar-auto');
    if (btnPueriIniciarAuto) {
        btnPueriIniciarAuto.addEventListener('click', () => {
            btnPueriIniciarAuto.textContent = "⏳ Puxando prontuário...";
          
            try {
                const buscarElemento = (seletor) => findElementDeep(seletor, window);

                const elIdade = buscarElemento('#IdentificadorUsuario_lblAgeFilledClone'), 
                      elSexo  = buscarElemento('#IdentificadorUsuario_lblSexFilledClone'), 
                      elPeso = buscarElemento('input[codigopergunta="1996"]'), 
                      elAlt  = buscarElemento('input[codigopergunta="1997"]'), 
                      elPc   = buscarElemento('input[codigopergunta="2322"]');

                const getValor = (el) => getFieldValue(el);

                const parseValorBR = (val) => parseBRNumber(val);
              
                const idadeBruta = elIdade ? elIdade.innerText : "";
                const sexoBruto  = elSexo  ? elSexo.innerText : ""; 
              
                let sexoLimpo = ""; 
                if (sexoBruto.toLowerCase().includes('masc')) sexoLimpo = 'M'; 
                if (sexoBruto.toLowerCase().includes('fem')) sexoLimpo = 'F';
              
                let anosLimpo = 0, mesesLimpo = 0; 
                const matchAnos  = idadeBruta.match(/(\d+)\s*ano/i);
                const matchMeses = idadeBruta.match(/(\d+)\s*m[êe]s/i); 
              
                if (matchAnos) anosLimpo = parseInt(matchAnos[1]); 
                if (matchMeses) mesesLimpo = parseInt(matchMeses[1]);
              
                const pesoLimpo = parseValorBR(getValor(elPeso)), 
                      altLimpa  = parseValorBR(getValor(elAlt)), 
                      pcLimpo   = parseValorBR(getValor(elPc));
              
                if (sexoLimpo) document.getElementById('cc-sexo').value = sexoLimpo; 
                if (!isNaN(anosLimpo)) document.getElementById('cc-anos').value = anosLimpo; 
                if (!isNaN(mesesLimpo)) document.getElementById('cc-mex').value = mesesLimpo; 
                if (!isNaN(pesoLimpo)) document.getElementById('cc-peso').value = pesoLimpo; 
                if (!isNaN(altLimpa)) document.getElementById('cc-alt').value = altLimpa; 
                if (!isNaN(pcLimpo)) document.getElementById('cc-pc').value = pcLimpo;

                let totalMonths = (anosLimpo * 12) + mesesLimpo;
                let pueriKey = '';
                if (anosLimpo >= 2) { pueriKey = '>2a'; }
                else if (totalMonths > 0 && totalMonths <= 24) { pueriKey = totalMonths + 'm'; }
                else if (totalMonths === 0) { pueriKey = '15d'; }
              
                const selectIdade = document.getElementById('pueri-idade');
                if (selectIdade && pueriKey) {
                    selectIdade.value = pueriKey;
                    selectIdade.dispatchEvent(new Event('change'));
                }

                if (!isNaN(pesoLimpo) || !isNaN(altLimpa)) {
                    setTimeout(() => {
                        document.getElementById('cc-calcular-unificado').click();
                        btnPueriIniciarAuto.innerHTML = "⚡ Iniciar Consulta Automática (1 Clique)";
                    }, 600);
                } else {
                    btnPueriIniciarAuto.innerHTML = "⚡ Iniciar Consulta Automática (1 Clique)";
                }

            } catch (e) { 
                btnPueriIniciarAuto.innerHTML = "⚡ Iniciar Consulta Automática (1 Clique)";
                alert("Erro ao extrair dados. Tente usar o botão manual."); 
            }
        });
    }

    // Botões de Limpar e Auto Manual Puericultura
    document.getElementById('cc-limpar-unificado').addEventListener('click', () => { 
      ['pueri-idade','cc-sexo','cc-anos','cc-mex','cc-peso','cc-alt','cc-pc'].forEach(id => document.getElementById(id).value = ''); 
      document.getElementById('resumo-unificado').style.display = 'none'; 
      document.getElementById('cc-resumo').style.display = 'none'; 
      document.getElementById('cc-charts').style.display = 'none'; 
      const isfSec = document.getElementById('pueri-isf-section'); 
      if(isfSec) isfSec.style.display = 'none';
      const btnExp = document.getElementById('export-unificado-btn'); 
      if (btnExp) {
          btnExp.dataset.avaliacao = ''; 
          btnExp.dataset.plano = ''; 
      }
      document.getElementById('cc-rtb').innerHTML = ''; 
      const pIdade = document.getElementById('pueri-idade'); 
      if(pIdade) pIdade.dispatchEvent(new Event('change'));
    });
  
    document.getElementById('cc-auto').addEventListener('click', () => {
      try {
        // G03 FIX: reutilizar funções centralizadas em vez de duplicar
        const buscarElemento = (seletor) => findElementDeep(seletor, window);
        const elIdade = buscarElemento('#IdentificadorUsuario_lblAgeFilledClone');
        const elSexo  = buscarElemento('#IdentificadorUsuario_lblSexFilledClone');
        const elPeso = buscarElemento('input[codigopergunta="1996"]');
        const elAlt  = buscarElemento('input[codigopergunta="1997"]');
        const elPc   = buscarElemento('input[codigopergunta="2322"]');
      
        const idadeBruta = elIdade ? elIdade.innerText : "";
        const sexoBruto  = elSexo  ? elSexo.innerText : ""; 
      
        let sexoLimpo = ""; 
        if (sexoBruto.toLowerCase().includes('masc')) sexoLimpo = 'M'; 
        if (sexoBruto.toLowerCase().includes('fem')) sexoLimpo = 'F';
      
        let anosLimpo = 0, mesesLimpo = 0; 
        const matchAnos  = idadeBruta.match(/(\d+)\s*ano/i);
        const matchMeses = idadeBruta.match(/(\d+)\s*m[êe]s/i); 
      
        if (matchAnos) anosLimpo = parseInt(matchAnos[1]); 
        if (matchMeses) mesesLimpo = parseInt(matchMeses[1]);
      
        const pesoLimpo = parseBRNumber(getFieldValue(elPeso));
        const altLimpa  = parseBRNumber(getFieldValue(elAlt));
        const pcLimpo   = parseBRNumber(getFieldValue(elPc));
      
        if (sexoLimpo) document.getElementById('cc-sexo').value = sexoLimpo; 
        if (!isNaN(anosLimpo)) document.getElementById('cc-anos').value = anosLimpo; 
        if (!isNaN(mesesLimpo)) document.getElementById('cc-mex').value = mesesLimpo; 
        if (!isNaN(pesoLimpo)) document.getElementById('cc-peso').value = pesoLimpo; 
        if (!isNaN(altLimpa)) document.getElementById('cc-alt').value = altLimpa; 
        if (!isNaN(pcLimpo)) document.getElementById('cc-pc').value = pcLimpo;
      
      } catch (e) { alert("Erro ao extrair dados manuais."); }
    });

    const ccChartState = {};

    function posicionarPontoCurva(dotId, coords) {
      const dot = document.getElementById(dotId);
      if (!dot) return;
      if (!coords || !Number.isFinite(coords.pointX) || !Number.isFinite(coords.pointY)) {
        dot.classList.remove('visible');
        dot.style.display = 'none';
        return;
      }
      dot.style.left = `${coords.pointX}px`;
      dot.style.top = `${coords.pointY}px`;
      dot.style.display = 'block';
      dot.classList.add('visible');
    }

    function limparPontoCurva(dotId) {
      const dot = document.getElementById(dotId);
      if (dot) { dot.style.display = 'none'; dot.classList.remove('visible'); }
    }

    function renderizarCurva(canvasId, dotId, data, meses, valor) {
      const canvas = document.getElementById(canvasId);
      if (!canvas) return;
      ccChartState[canvasId] = { dotId, data, meses, valor };
      limparPontoCurva(dotId);
      const executar = () => drawChart(canvas, data, meses, valor);
      requestAnimationFrame(executar);
      setTimeout(executar, 60);
      setTimeout(executar, 220);
    }

    window.addEventListener('beforeprint', () => {
      Object.values(ccChartState).forEach((cfg) => {
        const canvas = document.getElementById(Object.keys(ccChartState).find(k => ccChartState[k] === cfg) || '');
        if (canvas) drawChart(canvas, cfg.data, cfg.meses, cfg.valor);
      });
    });

    document.getElementById('cc-calcular-unificado').addEventListener('click', () => {
      const pueriKey = document.getElementById('pueri-idade').value;
      const sexo = document.getElementById('cc-sexo').value;
      const anosStr = document.getElementById('cc-anos').value.trim();
      const mexStr = document.getElementById('cc-mex').value.trim();
      const peso = parseFloat(document.getElementById('cc-peso').value);
      const alt = parseFloat(document.getElementById('cc-alt').value);
      const pcv = parseFloat(document.getElementById('cc-pc').value);

      const hasPueri = !!pueriKey;
      const hasCC = sexo && (anosStr !== '' || mexStr !== '') && (!isNaN(peso) || !isNaN(alt) || !isNaN(pcv));

      if (!hasPueri && !hasCC) { 
          alert('Preencha a idade e os dados antropométricos para calcular.'); 
          return; 
      }

      document.getElementById('resumo-unificado').style.display = 'block';

      let textoExportacao = "";
      let textoDesenvolvimento = "";
      let textoPlanoFinal = "";

      if (hasPueri) {
          const title = document.getElementById('pueri-titulo').textContent;
          const dnpm = document.getElementById('pueri-dnpm').textContent;
          const dieta = document.getElementById('pueri-dieta').textContent;
          const cond = document.getElementById('pueri-conduta').textContent;
          textoDesenvolvimento = `- Desenvolvimento (${title}): ${dnpm}
- Alimentação: ${dieta}
- Orientações gerais: ${cond}`;
      }

      if (hasPueri && !hasCC) {
        // REQUISITO 1: sem dados antropométricos, não há plano antropométrico para exportar.
        textoPlanoFinal = "";
      }

      if (hasCC) {
        const anos = parseFloat(anosStr) || 0, mex = parseFloat(mexStr) || 0; const meses = anos * 12 + mex;
        if (meses > 215) { alert('As curvas estão disponíveis até 17 anos e 11 meses.'); return; }

        const usarReferenciaEstendida = meses > 60;
        const PD = sexo==='M' ? (usarReferenciaEstendida ? PESO_M_EXT : PESO_M) : (usarReferenciaEstendida ? PESO_F_EXT : PESO_F);
        const AD = sexo==='M' ? (usarReferenciaEstendida ? ALT_M_EXT  : ALT_M)  : (usarReferenciaEstendida ? ALT_F_EXT  : ALT_F);
        const ID = sexo==='M' ? (usarReferenciaEstendida ? IMC_M_EXT  : IMC_M)  : (usarReferenciaEstendida ? IMC_F_EXT  : IMC_F);
        const CD = usarReferenciaEstendida ? null : (sexo==='M' ? PC_M : PC_F);
        const imc = (!isNaN(peso) && !isNaN(alt)) ? peso / ((alt/100)**2) : NaN;
        const zP = !isNaN(peso) ? calcZScore(peso, interp(PD, meses)) : null; 
        const zA = !isNaN(alt) ? calcZScore(alt,  interp(AD, meses)) : null; 
        const zI = !isNaN(imc) ? calcZScore(imc,  interp(ID, meses)) : null; 
        const zC = (!usarReferenciaEstendida && CD && !isNaN(pcv)) ? calcZScore(pcv, interp(CD, meses)) : null;
      
        const zP_val = zP !== null ? parseFloat(zP) : NaN; 
        const zA_val = zA !== null ? parseFloat(zA) : NaN; 
        const zI_val = zI !== null ? parseFloat(zI) : NaN; 
        const zC_val = zC !== null ? parseFloat(zC) : NaN;
      
        const sl = sexo==='M' ? 'Masculino' : 'Feminino'; 
        const idStr = anos > 0 ? (mex > 0 ? `${anos}a ${mex}m (${meses}m)` : `${anos}a (${meses}m)`) : `${meses}m`;
      
        const tb = document.getElementById('cc-rtb'); tb.innerHTML = '';
        const ti = document.createElement('tr'); 
        ti.innerHTML = `<td colspan="4" style="font-size:10px;color:#5a5650;padding:5px 8px;background:#f9f7f4"><b>Sexo:</b> ${escapeHtml(sl)} · <b>Idade:</b> ${escapeHtml(idStr)} ${!isNaN(peso)? '· <b>Peso:</b> '+escapeHtml(peso)+' kg' : ''} ${!isNaN(alt)? '· <b>Altura:</b> '+escapeHtml(alt)+' cm' : ''} ${!isNaN(imc)? '· <b>IMC:</b> '+escapeHtml(imc.toFixed(1))+' kg/m²' : ''} ${!isNaN(pcv) ? ' · <b>PC:</b> '+escapeHtml(pcv)+' cm' : ''}</td>`; 
        tb.appendChild(ti);
      
        const addRow = (lbl, v, z, tipo) => { 
            const classObj = getZClass(z, tipo); 
            const tr = document.createElement('tr'); 
            tr.innerHTML = `<td><b>${lbl}</b></td><td>${v}</td><td><b>Z ${z}</b></td><td><span class="cc-badge ${classObj.c}">${classObj.m}</span></td>`; 
            tb.appendChild(tr); 
        };
      
        if(zP !== null) addRow('Peso / Idade', `${peso} kg`, zP, 'peso'); 
        if(zA !== null) addRow('Altura / Idade', `${alt} cm`, zA, 'alt'); 
        if(zI !== null) addRow('IMC / Idade', `${imc.toFixed(1)} kg/m²`, zI, 'imc'); 
        if(zC !== null) addRow('PC / Idade', `${pcv} cm`, zC, 'pc');
      
        textoExportacao = `》AVALIAÇÃO ANTROPOMÉTRICA:`;
        if(zP !== null) textoExportacao += `\n- Peso/Idade: ${peso} kg (Z ${zP} - ${getZClass(zP, 'peso').m})`; 
        if(zA !== null) textoExportacao += `\n- Estatura/Idade: ${alt} cm (Z ${zA} - ${getZClass(zA, 'alt').m})`; 
        if(zI !== null) textoExportacao += `\n- IMC/Idade: ${imc.toFixed(1)} kg/m² (Z ${zI} - ${getZClass(zI, 'imc').m})`; 
        if(zC !== null) textoExportacao += `\n- PC/Idade: ${pcv} cm (Z ${zC} - ${getZClass(zC, 'pc').m})`;
      
        let planos = [];
        if ((!isNaN(zP_val) && zP_val < -2) || (!isNaN(zI_val) && zI_val < -2)) { planos.push("Paciente com baixo peso / magreza. Avaliada dinâmica alimentar familiar e técnica de oferta/amamentação. Orientado enriquecimento calórico-proteico das refeições com alimentos in natura (óleos vegetais, raízes, leguminosas), sem introdução de ultraprocessados. Retorno precoce programado em 15 a 30 dias para reavaliação da curva de peso."); }
        if (!isNaN(zI_val) && zI_val > 1 && zI_val <= 3) { planos.push("Paciente em risco de sobrepeso / sobrepeso. Realizada orientação nutricional focada na redução de alimentos ultraprocessados, adequação do fracionamento das refeições e estímulo ao consumo de alimentos in natura. Recomendado aumento de atividade física lúdica e redução de tempo de tela. Agendado retorno precoce em 30 a 60 dias para reavaliação de ganho ponderal e adesão às mudanças de estilo de vida."); }
        if (!isNaN(zI_val) && zI_val > 3) { planos.push("Paciente com obesidade / obesidade grave. Orientada mudança intensiva de estilo de vida (MEV) envolvendo todo o núcleo familiar. Foco central na eliminação de bebidas açucaradas, restrição severa de telas e planejamento alimentar baseado no Guia Alimentar. Avaliada necessidade de exames de rastreio metabólico inicial (conforme faixa etária e protocolo municipal). Retorno precoce em 30 dias para monitoramento rigoroso e suporte contínuo."); }
        if (!isNaN(zA_val) && zA_val < -2) { planos.push("Paciente com baixa estatura para a idade. Avaliado histórico familiar (alvo genético) e curva pregressa para cálculo da velocidade de crescimento. Reforçada a importância da adequação nutricional e higiene do sono. Mantida vigilância estrita: caso a velocidade de crescimento se mantenha inadequada ou haja dismorfias associadas, planejar encaminhamento à endocrinologia pediátrica. Retorno precoce programado em 30 dias para reavaliação da curva de estatura."); }
        if (!isNaN(zC_val) && (zC_val < -2 || zC_val > 2)) { const condicaoPC = zC_val < -2 ? "Microcefalia" : "Macrocefalia"; planos.push(`Alteração no perímetro cefálico identificada (${condicaoPC}). Realizado exame físico neurológico detalhado e avaliação minuciosa do desenvolvimento neuropsicomotor (DNPM). Família orientada sobre os achados. Agendado retorno em curto prazo para seguimento clínico estrito.`); }
      
        const textoPlanoCrescimento = planos.length === 0 ? "Parâmetros antropométricos adequados para a idade e sexo (eutrofia e estatura adequada). Reforçadas orientações de alimentação saudável, atividade física/brincadeiras e seguimento de puericultura." : planos.join("\n\n");
        // REQUISITO 1: plano terapêutico contém APENAS o bloco antropométrico (Z-Score).
        // O textoDesenvolvimento (alimentação/orientações gerais) não vai mais para o plano.
        textoPlanoFinal = textoPlanoCrescimento;
      
        document.getElementById('cc-resumo').style.display = 'block'; 
        document.getElementById('cc-charts').style.display  = 'block';
      
        const badge = (z, tipo) => { const classObj = getZClass(z, tipo); return `<span class="cc-badge ${classObj.c}">Z ${z} — ${classObj.m}</span>`; };
      
        const pcCard = document.getElementById('cc-pc-card');
        if (pcCard) pcCard.style.display = usarReferenciaEstendida ? 'none' : ''; if (usarReferenciaEstendida) limparPontoCurva('cc-dot-PC');

        if(zP !== null) { document.getElementById('cc-mPI').textContent  = `${sl} · ${meses}m · ${peso} kg`; document.getElementById('cc-bPI').innerHTML  = badge(zP,'peso'); renderizarCurva('cc-cPI', 'cc-dot-PI', PD, meses, peso); } else { document.getElementById('cc-mPI').textContent = 'Peso não informado'; document.getElementById('cc-bPI').innerHTML = '<span class="cc-no-data">Informe o Peso para visualizar.</span>'; const cv = document.getElementById('cc-cPI'); const ctx = cv.getContext('2d'); ctx.clearRect(0,0,cv.width,cv.height); limparPontoCurva('cc-dot-PI'); }
        if(zA !== null) { document.getElementById('cc-mAI').textContent  = `${sl} · ${meses}m · ${alt} cm`; document.getElementById('cc-bAI').innerHTML  = badge(zA,'alt'); renderizarCurva('cc-cAI', 'cc-dot-AI', AD, meses, alt); } else { document.getElementById('cc-mAI').textContent = 'Altura não informada'; document.getElementById('cc-bAI').innerHTML = '<span class="cc-no-data">Informe a Altura para visualizar.</span>'; const cv = document.getElementById('cc-cAI'); const ctx = cv.getContext('2d'); ctx.clearRect(0,0,cv.width,cv.height); limparPontoCurva('cc-dot-AI'); }
        if(zI !== null) { document.getElementById('cc-mIMC').textContent = `${sl} · ${meses}m · IMC ${imc.toFixed(1)} kg/m²`; document.getElementById('cc-bIMC').innerHTML = badge(zI,'imc'); renderizarCurva('cc-cIMC', 'cc-dot-IMC', ID, meses, imc); } else { document.getElementById('cc-mIMC').textContent = 'Dados incompletos'; document.getElementById('cc-bIMC').innerHTML = '<span class="cc-no-data">Necessário Peso e Altura.</span>'; const cv = document.getElementById('cc-cIMC'); const ctx = cv.getContext('2d'); ctx.clearRect(0,0,cv.width,cv.height); limparPontoCurva('cc-dot-IMC'); }
        if(!usarReferenciaEstendida) {
            if(zC !== null) { document.getElementById('cc-mPC').textContent = `${sl} · ${meses}m · ${pcv} cm`; document.getElementById('cc-bPC').innerHTML   = badge(zC,'pc'); renderizarCurva('cc-cPC', 'cc-dot-PC', CD, meses, pcv); } else { document.getElementById('cc-mPC').textContent = 'PC não informado'; document.getElementById('cc-bPC').innerHTML   = '<span class="cc-no-data">Informe o PC para visualizar.</span>'; const cv = document.getElementById('cc-cPC'); const ctx = cv.getContext('2d'); ctx.clearRect(0,0,cv.width,cv.height); limparPontoCurva('cc-dot-PC'); }
        }

      } else {
        document.getElementById('cc-resumo').style.display = 'none'; 
        document.getElementById('cc-charts').style.display  = 'none';
      }
    
      const isfPueriSection = document.getElementById('pueri-isf-section');
      if (isfPueriSection) isfPueriSection.style.display = 'block';

      const btnExp = document.getElementById('export-unificado-btn'); 
      if (btnExp) {
          btnExp.dataset.avaliacao = textoExportacao.trim(); 
          btnExp.dataset.plano = textoPlanoFinal ? `》PLANO TERAPÊUTICO:
${textoPlanoFinal}`.trim() : "";
      }
    });

    // REQUISITO 2: monta payload da puericultura médica adicionando
    // 0301010285 (Avaliação Maturação Sexual) quando idade >= 10 anos.
    function montarPayloadPueriMedico() {
        const base = ISF_CODES.medico.puericultura || {};
        const procedimentosBase = Array.isArray(base.procedimentos) ? [...base.procedimentos] : [];

        // Obter idade total em meses a partir dos campos do painel
        const pueriKey = (document.getElementById('pueri-idade')?.value || '').trim();
        const anosNum = parseFloat(document.getElementById('cc-anos')?.value);
        const mesesNum = parseFloat(document.getElementById('cc-mex')?.value);

        let idadeAnos = NaN;
        if (!isNaN(anosNum) || !isNaN(mesesNum)) {
            const a = isNaN(anosNum) ? 0 : anosNum;
            const m = isNaN(mesesNum) ? 0 : mesesNum;
            idadeAnos = a + (m / 12);
        } else if (pueriKey === '>2a') {
            // '>2a' indica criança maior de 2 anos mas sem valor numérico preciso;
            // sem os campos de anos/meses preenchidos, não dá para saber se chegou a 10a.
            idadeAnos = NaN;
        } else if (/^\d+m$/.test(pueriKey)) {
            idadeAnos = parseInt(pueriKey, 10) / 12;
        }

        if (!isNaN(idadeAnos) && idadeAnos >= 10) {
            // Evitar duplicação caso já exista
            const jaTem = procedimentosBase.some((p) => String(p).includes('0301010285'));
            if (!jaTem) procedimentosBase.push('0301010285');
        }

        return { ...base, procedimentos: procedimentosBase };
    }

    const btnPueriIsfMed = document.getElementById('pueri-isf-medico');
    if (btnPueriIsfMed) {
        btnPueriIsfMed.addEventListener('click', async () => {
            const btnOriginal = btnPueriIsfMed.textContent; 
            const payload = montarPayloadPueriMedico();
            const temMaturacao = (payload.procedimentos || []).some((p) => String(p).includes('0301010285'));
            const label = temMaturacao ? '👶 Puericultura (Médico) + Maturação Sexual' : '👶 Puericultura (Médico)';
            const ok = await enviarISFComConfirmacao(payload, label);
            if (ok) { btnPueriIsfMed.textContent = '⏳ Lançando...'; setTimeout(() => btnPueriIsfMed.textContent = btnOriginal, 2000); }
        });
    }

    const btnPueriIsfEnf = document.getElementById('pueri-isf-enfermagem');
    if (btnPueriIsfEnf) {
        btnPueriIsfEnf.addEventListener('click', async () => {
            const btnOriginal = btnPueriIsfEnf.textContent;
            const ok = await enviarISFComConfirmacao(ISF_CODES.enfermagem.puericultura, '👶 Puericultura (Enfermagem)');
            if (ok) { btnPueriIsfEnf.textContent = '⏳ Lançando...'; setTimeout(() => btnPueriIsfEnf.textContent = btnOriginal, 2000); }
        });
    }

    document.getElementById('export-unificado-btn').addEventListener('click', async (e) => { 
      const txtAvaliacao = e.target.dataset.avaliacao; const txtPlano = e.target.dataset.plano;
      if (txtAvaliacao || txtPlano) {
        const resumo = [txtAvaliacao, txtPlano].filter(Boolean).join('\n\n');
        await enviarCondutaComConfirmacao({ type: 'PUERI_CC_INSERIR_CONDUTA', avaliacao: txtAvaliacao, plano: txtPlano }, resumo);
      }
    });
    const btnPrint = document.getElementById('cc-print-btn'); 
    if (btnPrint) btnPrint.addEventListener('click', () => { window.print(); }); 

    // ==========================================
    // FUNÇÃO MATEMÁTICA PREVENT GLOBAL

    const adlPeso = document.getElementById('adl-peso');
    const adlAlt = document.getElementById('adl-alt');
    const adlImcDisplay = document.getElementById('adl-imc-display');
    const chkSemComorb = document.getElementById('chk-sem-comorb');
    const chkHas = document.getElementById('chk-has');
    const chkDm = document.getElementById('chk-dm');
    const chkDislip = document.getElementById('chk-dislip');
    const chkEventoCV = document.getElementById('chk-evento-cv');
    const preventBox = document.getElementById('adl-prevent-box');

    function atualizarVisibilidadePreventBox() {
        if (!preventBox) return;
        preventBox.style.display = 'block';
    }

    function sincronizarCheckSemComorb() {
        if (!chkSemComorb) return;
        const temLinhaAtiva = Boolean((chkHas && chkHas.checked) || (chkDm && chkDm.checked) || (chkDislip && chkDislip.checked) || (chkEventoCV && chkEventoCV.checked));
        if (temLinhaAtiva) chkSemComorb.checked = false;
    }

    if (chkSemComorb) {
        chkSemComorb.addEventListener('change', (e) => {
            if (!e.target.checked) return;
            if (chkHas) chkHas.checked = false;
            if (chkDm) chkDm.checked = false;
            if (chkDislip) chkDislip.checked = false;
            if (chkEventoCV) chkEventoCV.checked = false;
            atualizarVisibilidadePreventBox();
        });
    }

    [chkHas, chkDm, chkDislip, chkEventoCV].forEach((chk) => {
        if (!chk) return;
        chk.addEventListener('change', () => {
            sincronizarCheckSemComorb();
            atualizarVisibilidadePreventBox();
        });
    });

    atualizarVisibilidadePreventBox();

    const adlPrevAutoBtn = document.getElementById('adl-prev-auto-btn');
    if (adlPrevAutoBtn) {
        adlPrevAutoBtn.addEventListener('click', () => {
            let btn = document.getElementById('adl-prev-auto-btn'); btn.textContent = '⏳ Buscando...';
            enviarParaFrames(window, { type: 'PREVENT_PEDIR_DADOS' });
            setTimeout(() => { if (btn.textContent === '⏳ Buscando...') btn.textContent = '⚡ Puxar labs do prontuário'; }, 2000);
        });
    }

    function calcularIMCAdulto() {
        const p = parseFloat(adlPeso.value); const a = parseFloat(adlAlt.value);
        if (!isNaN(p) && !isNaN(a) && a > 0) {
            const imc = p / ((a/100)**2); let classif = ""; let cor = "";
            if (imc < 18.5) { classif = "Magreza"; cor = "#d97706"; } else if (imc < 25) { classif = "Eutrofia"; cor = "#16a34a"; } else if (imc < 30) { classif = "Sobrepeso"; cor = "#ea580c"; } else if (imc < 35) { classif = "Obesidade Grau I"; cor = "#dc2626"; } else if (imc < 40) { classif = "Obesidade Grau II"; cor = "#b91c1c"; } else { classif = "Obesidade Grau III"; cor = "#991b1b"; }
            adlImcDisplay.innerHTML = `<span style="color:${cor}">${escapeHtml(imc.toFixed(1))} kg/m² (${escapeHtml(classif)})</span>`;
            return { imc: imc.toFixed(1), classif, cor };
        }
        adlImcDisplay.innerHTML = "--"; return null;
    }

    function obterIdadePlanoAdulto() {
        const idade = parseFloat(document.getElementById('adl-prev-idade')?.value);
        return isNaN(idade) ? null : idade;
    }

    function ehIdosoParaPlano(idade) {
        return idade !== null && idade >= 60;
    }

    function temExcessoDePeso(imcData) {
        if (!imcData) return false;
        return ['Sobrepeso', 'Obesidade Grau I', 'Obesidade Grau II', 'Obesidade Grau III'].includes(imcData.classif);
    }

    function obterResumoNutricionalAdulto(imcData) {
        if (!imcData) return 'Antropometria não preenchida.';
        return `Paciente com ${imcData.classif.toLowerCase()} (IMC ${imcData.imc} kg/m²).`;
    }

    function obterSexoPlanoAdulto() {
        const sexo = document.getElementById('adl-prev-sexo')?.value || '';
        return ['M', 'F'].includes(sexo) ? sexo : '';
    }

    function montarRastreiosSaudeFeminina({ idade, sexo }) {
        if (idade === null || !sexo) return [];
        if (sexo !== 'F') return [];

        const itens = [];
        if (idade >= 25 && idade <= 64) {
            itens.push('Rastreamento do câncer do colo do útero conforme protocolo vigente e intervalo aplicável.');
        }
        if (idade >= 50 && idade <= 74) {
            itens.push('Mamografia de rastreamento bienal se assintomática e sem alto risco específico.');
        }

        if (!itens.length) return [];
        return [{
            titulo: 'Rastreamento da saúde feminina:',
            itens,
        }];
    }

    function montarRastreiosSemComorbidades({ idade, sexo }) {
        if (idade === null || !sexo) {
            return [{
                titulo: 'Sem comorbidades:',
                itens: ['Preencher idade e sexo para mostrar rastreios oportunos conforme faixa etária.'],
            }];
        }

        return [{
            titulo: 'Sem comorbidades:',
            itens: ['Manter medidas de prevenção, hábitos de vida saudáveis e rastreios oportunos conforme idade, sexo e contexto clínico.'],
        }];
    }

    function formatarSecoesRastreio(secoes) {
        if (!Array.isArray(secoes) || secoes.length === 0) return 'Sem linha de cuidado específica marcada nesta tela.';
        return secoes
            .map((secao) => {
                const titulo = secao?.titulo || '';
                const itens = Array.isArray(secao?.itens) ? secao.itens : [];
                if (!itens.length) return titulo;
                return `${titulo}\n${itens.map((item) => `- ${item}`).join('\n')}`;
            })
            .join('\n\n');
    }


    function montarExamesRastreioAdulto({ has, dm, dislip, semComorb, eventoCVPrevio, idade, sexo }) {
        const secoes = [];
        if (has) {
            secoes.push({
                titulo: 'HAS:',
                itens: ['Creatinina/TFG', 'Potássio', 'Urina tipo 1', 'Perfil lipídico', 'ECG conforme contexto clínico.'],
            });
        }
        if (dm) {
            secoes.push({
                titulo: 'DM:',
                itens: ['HbA1c', 'Creatinina/TFG', 'Microalbuminúria de amostra isolada', 'Avaliação dos pés', 'Rastreio oftalmológico.'],
            });
        }
        if (dislip || eventoCVPrevio) {
            secoes.push({
                titulo: 'Dislipidemia / prevenção secundária:',
                itens: ['Perfil lipídico e revisão de adesão ao tratamento, além de causas secundárias quando pertinente.'],
            });
        }
        secoes.push(...montarRastreiosSaudeFeminina({ idade, sexo }));
        if (semComorb) secoes.push(...montarRastreiosSemComorbidades({ idade, sexo }));
        if (secoes.length === 0) {
            secoes.push({
                titulo: 'Sem regra específica:',
                itens: ['Sem rastreio oportuno específico configurado nesta tela apenas por idade/sexo.'],
            });
        }
        return formatarSecoesRastreio(secoes);
    }

    function obterDadosPreventAdulto({ has, dm, dislip, eventoCVPrevio }) {
        if (eventoCVPrevio) {
            const metas = obterMetasPrevent(0, 'muito_alto');
            return {
                status: 'muito_alto_evento',
                risco: null,
                metas,
                categoria: metas.cat,
                categoriaTexto: metas.catTexto,
            };
        }

        // REQUISITO: calcular PREVENT para todo paciente elegível, não apenas quando dislip marcada
        const idade = parseFloat(document.getElementById('adl-prev-idade').value);
        const sexo = document.getElementById('adl-prev-sexo').value;
        const pas = parseFloat(document.getElementById('adl-prev-pas').value);
        const colTotal = parseFloat(document.getElementById('adl-prev-col').value);
        const hdl = parseFloat(document.getElementById('adl-prev-hdl').value);
        const tfg = parseFloat(document.getElementById('adl-prev-tfg').value);
        const tabaco = document.getElementById('adl-prev-tabaco').checked ? 1 : 0;
        const isDmPrev = dm ? 1 : 0;
        // Conservador: estatina só quando dislip marcada. eventoCV não entra mais aqui
        // porque já tratamos o caso eventoCVPrevio acima e nunca chega neste ponto.
        const isEstatina = dislip ? 1 : 0;
        const isAntiHiper = has ? 1 : 0;

        if ([idade, pas, colTotal, hdl, tfg].some((valor) => isNaN(valor)) || !sexo) {
            return { status: 'faltam_dados', metas: null, risco: null, categoria: '', categoriaTexto: '' };
        }

        const risco = calcularRiscoAHA(idade, sexo, pas, colTotal, hdl, isDmPrev, tabaco, isEstatina, isAntiHiper, tfg);
        if (risco === null) {
            return { status: 'fora_faixa', metas: null, risco: null, categoria: '', categoriaTexto: '' };
        }

        const metas = obterMetasPrevent(risco);
        return {
            status: 'ok',
            risco,
            metas,
            categoria: metas.cat,
            categoriaTexto: metas.catTexto,
        };
    }

    function montarCondutasAdulto({ has, dm, dislip, semComorb, eventoCVPrevio, imcData, idade, preventInfo }) {
        const condutas = [];
        const idoso = ehIdosoParaPlano(idade);

        if (semComorb) {
            condutas.push(adultoTexts.PREVENCAO_GERAL || '» PREVENÇÃO GERAL: Sem comorbidades cardiometabólicas marcadas nesta avaliação. Orientado manter alimentação adequada, atividade física regular, controle de peso, evitar tabagismo e realizar rastreios oportunos conforme idade, sexo e contexto clínico.');
        }

        if (has) {
            condutas.push((adultoTexts.getHasText && adultoTexts.getHasText({ idoso })) || '» HIPERTENSÃO (HAS): Meta pressórica preferencial < 130/80 mmHg, conforme tolerância. Orientado reduzir sal, manter atividade física regular, evitar tabagismo, usar corretamente as medicações e retornar com medidas pressóricas quando solicitado.');
        }

        if (dm) {
            condutas.push((adultoTexts.getDmText && adultoTexts.getDmText({ idoso })) || '» DIABETES (DM): Meta de HbA1c < 7%. Orientado reduzir açúcar e ultraprocessados, manter atividade física, aderir ao tratamento, cuidar dos pés e reconhecer sinais de hipoglicemia.');
        }

        if (dislip || eventoCVPrevio) {
            if (preventInfo.status === 'muito_alto_evento') {
                condutas.push((adultoTexts.getDislipTextMuitoAlto && adultoTexts.getDislipTextMuitoAlto({ metaLDL: preventInfo.metas.metaLDL, metaNaoHDL: preventInfo.metas.metaNaoHDL })) || `» DISLIPIDEMIA: Muito alto risco cardiovascular por doença cardiovascular prévia. Meta de LDL < ${preventInfo.metas.metaLDL} mg/dL e colesterol não-HDL < ${preventInfo.metas.metaNaoHDL} mg/dL. Orientado reduzir gordura saturada e ultraprocessados, manter perda de peso se necessário, fazer atividade física e usar corretamente a medicação.`);
            } else if (preventInfo.status === 'ok') {
                condutas.push((adultoTexts.getDislipTextCalculado && adultoTexts.getDislipTextCalculado({ categoriaTexto: preventInfo.categoriaTexto, risco: preventInfo.risco.toFixed(1), metaLDL: preventInfo.metas.metaLDL, metaNaoHDL: preventInfo.metas.metaNaoHDL })) || `» DISLIPIDEMIA: Risco cardiovascular ${preventInfo.categoriaTexto} (${preventInfo.risco.toFixed(1)}% em 10 anos). Meta de LDL < ${preventInfo.metas.metaLDL} mg/dL e colesterol não-HDL < ${preventInfo.metas.metaNaoHDL} mg/dL. Orientado reduzir gordura saturada e ultraprocessados, manter perda de peso se necessário, fazer atividade física e usar corretamente a medicação.`);
            } else if (preventInfo.status === 'fora_faixa') {
                condutas.push(adultoTexts.DISLIP_FORA_FAIXA || '» DISLIPIDEMIA: PREVENT aplicável apenas de 30 a 79 anos; definir metas lipídicas conforme contexto clínico.');
            } else {
                condutas.push(adultoTexts.DISLIP_FALTAM_DADOS || '» DISLIPIDEMIA: Preencher dados necessários para cálculo do risco cardiovascular e definição das metas lipídicas.');
            }
        } else if (preventInfo.status === 'ok') {
            // REQUISITO: paciente sem dislipidemia marcada, mas com dados suficientes para PREVENT.
            // Sempre informar o risco calculado e as metas lipídicas preventivas no plano.
            condutas.push(
                (adultoTexts.getRiscoCVTextCalculado && adultoTexts.getRiscoCVTextCalculado({
                    categoriaTexto: preventInfo.categoriaTexto,
                    risco: preventInfo.risco.toFixed(1),
                    metaLDL: preventInfo.metas.metaLDL,
                    metaNaoHDL: preventInfo.metas.metaNaoHDL,
                })) ||
                `» RISCO CARDIOVASCULAR (PREVENT): Risco ${preventInfo.categoriaTexto} (${preventInfo.risco.toFixed(1)}% em 10 anos, AHA 2023). Meta preventiva de LDL < ${preventInfo.metas.metaLDL} mg/dL e colesterol não-HDL < ${preventInfo.metas.metaNaoHDL} mg/dL.`
            );
        }
        // Se !dislip && !eventoCV e status != 'ok' (faltam dados ou fora de faixa), não mostra nada.

        if (temExcessoDePeso(imcData)) {
            const riscoModeradoAlto = preventInfo?.status === 'ok' && preventInfo.risco >= 5;
            const riscoClinicoAlto = preventInfo?.status === 'muito_alto_evento';
            condutas.push((adultoTexts.getPesoText && adultoTexts.getPesoText({ classif: imcData.classif, riscoModeradoOuAlto: (riscoModeradoAlto || riscoClinicoAlto) })) || `» PESO / OBESIDADE: ${imcData.classif}. Meta inicial de perda ponderal de 5%. Orientado manter alimentação adequada, reduzir ultraprocessados e manter atividade física regular.`);
        }

        return condutas;
    }

    if(adlPeso) adlPeso.addEventListener('input', calcularIMCAdulto);
    if(adlAlt) adlAlt.addEventListener('input', calcularIMCAdulto);

    const btnGerarPlanoAdulto = document.getElementById('btn-gerar-plano-adulto');
    if (btnGerarPlanoAdulto) {
        btnGerarPlanoAdulto.addEventListener('click', () => {
            const imcData = calcularIMCAdulto();
            const semComorb = document.getElementById('chk-sem-comorb').checked;
            const has = document.getElementById('chk-has').checked;
            const dm = document.getElementById('chk-dm').checked;
            const dislip = document.getElementById('chk-dislip').checked;
            const eventoCVPrevio = document.getElementById('chk-evento-cv').checked;
            const idadePlano = obterIdadePlanoAdulto();
            const preventInfo = obterDadosPreventAdulto({ has, dm, dislip, eventoCVPrevio });

            const txtNutri = obterResumoNutricionalAdulto(imcData);
            const sexoPlano = obterSexoPlanoAdulto();
            const exames = montarExamesRastreioAdulto({ has, dm, dislip, semComorb, eventoCVPrevio, idade: idadePlano, sexo: sexoPlano });
            const condutas = montarCondutasAdulto({ has, dm, dislip, semComorb, eventoCVPrevio, imcData, idade: idadePlano, preventInfo });

            document.getElementById('adl-res-nutri').textContent = txtNutri;
            document.getElementById('adl-res-exames').textContent = exames;
            document.getElementById('adl-res-conduta').textContent = condutas.length > 0 ? condutas.join("\n") : 'Nenhuma meta exportável gerada com os dados atuais.';
            document.getElementById('adl-resultado').style.display = 'block';

            const textoExportacao = condutas.length > 0 ? `》METAS E ORIENTAÇÕES AO PACIENTE:
${condutas.join("\n")}` : '';
            const btnExport = document.getElementById('adl-export-btn');
            btnExport.dataset.texto = textoExportacao;
            btnExport.style.display = condutas.length > 0 ? 'block' : 'none';

            const isfSection = document.getElementById('adl-isf-section');
            const isfContainer = document.getElementById('adl-isf-actions');
            isfContainer.innerHTML = '';
            if (has || dm) {
                isfSection.style.display = 'block';
                if (has) isfContainer.appendChild(criarBotaoISF('❤️ Lançar Procedimentos (HAS)', ISF_CODES.medico.hipertensao));
                if (dm) isfContainer.appendChild(criarBotaoISF('🩸 Lançar Procedimentos (DM)', ISF_CODES.medico.diabetes));
            } else {
                isfSection.style.display = 'none';
            }
        });
    }

    function criarBotaoISF(label, payload) {
        const btn = document.createElement('button'); btn.className = 'isf-btn'; btn.textContent = label;
        btn.onclick = async () => { const btnOriginal = btn.textContent; const ok = await enviarISFComConfirmacao(payload, label); if (ok) { btn.textContent = '⏳ Lançando...'; setTimeout(() => btn.textContent = btnOriginal, 2000); } };
        return btn;
    }

    const btnExportAdulto = document.getElementById('adl-export-btn');
    if(btnExportAdulto) btnExportAdulto.addEventListener('click', async (e) => { await enviarCondutaComConfirmacao({ type: 'ADL_INSERIR_CONDUTA', texto: e.target.dataset.texto }, e.target.dataset.texto); });
  
    const adlAutoBtn = document.getElementById('adl-auto-btn');
    if(adlAutoBtn) {
        adlAutoBtn.addEventListener('click', () => {
            const buscarElemento = (seletor) => findElementDeep(seletor, window);
            const elPeso = buscarElemento('input[codigopergunta="1996"]'); const elAlt  = buscarElemento('input[codigopergunta="1997"]');
            const getValor = (el) => getFieldValue(el);
            const parseValorBR = (val) => parseBRNumber(val);
            const peso = parseValorBR(getValor(elPeso)); const alt = parseValorBR(getValor(elAlt));
            if(!isNaN(peso)) adlPeso.value = peso; if(!isNaN(alt)) adlAlt.value = alt;
            calcularIMCAdulto();
        });
    }

    const preventAutoBtn = document.getElementById('prevent-auto-btn');
    if(preventAutoBtn) {
        preventAutoBtn.addEventListener('click', () => {
          const msgPrev = document.getElementById('prevent-auto-msg'); if(msgPrev) { msgPrev.textContent = 'Buscando dados e exames...'; msgPrev.style.color = '#7dd3fc'; }
          enviarParaFrames(window, { type: 'PREVENT_PEDIR_DADOS' });
          setTimeout(() => { const msg = document.getElementById('prevent-auto-msg'); if (msg && msg.textContent === 'Buscando dados e exames...') { msg.textContent = '⚠ Dados não encontrados na tela.'; msg.style.color = '#fbbf24'; setTimeout(() => msg.textContent = '', 3000); } }, 2000);
        });
    }

    const preventCalcBtn = document.getElementById('prevent-calc-btn');
    if(preventCalcBtn) {
        preventCalcBtn.addEventListener('click', () => {
          const idade = parseFloat(document.getElementById('prev-idade').value); const sexo = document.getElementById('prev-sexo').value; const pas = parseFloat(document.getElementById('prev-pas').value); const colTotal = parseFloat(document.getElementById('prev-colTotal').value); const hdl = parseFloat(document.getElementById('prev-hdl').value); const dm = document.getElementById('prev-dm').checked ? 1 : 0; const tabaco = document.getElementById('prev-tabaco').checked ? 1 : 0; const eventoCV = document.getElementById('prev-evento-cv')?.checked ? 1 : 0; const estatina = document.getElementById('prev-estatina').checked ? 1 : 0; const antiHiper = document.getElementById('prev-antihiper').checked ? 1 : 0; const tfg = parseFloat(document.getElementById('prev-tfg').value);
          const r = document.getElementById('prevent-resultado');
          const exportBtn = document.getElementById('prevent-export-btn');

          if (eventoCV) {
            const metas = obterMetasPrevent(0, 'muito_alto');
            r.style.display = 'block';
            document.getElementById('prev-risco-valor').textContent = '—';
            document.getElementById('prev-risco-valor').style.color = metas.cor;
            document.getElementById('prev-risco-cat').textContent = 'MUITO ALTO RISCO';
            document.getElementById('prev-risco-cat').style.color = metas.cor;
            document.getElementById('prev-risco-cat').style.borderColor = metas.cor;
            document.getElementById('prev-conduta').textContent = `Doença cardiovascular prévia marcada. Meta de LDL < ${metas.metaLDL} mg/dL e colesterol não-HDL < ${metas.metaNaoHDL} mg/dL.`;
            if (exportBtn) exportBtn.style.display = 'block';
            r.dataset.risco = 'não aplicável';
            r.dataset.categoria = 'MUITO ALTO RISCO';
            r.dataset.conduta = `Doença cardiovascular prévia marcada. Meta de LDL < ${metas.metaLDL} mg/dL e colesterol não-HDL < ${metas.metaNaoHDL} mg/dL.`;
            return;
          }

          if (isNaN(idade) || isNaN(pas) || isNaN(colTotal) || isNaN(hdl) || isNaN(tfg)) { r.style.display = 'block'; document.getElementById('prev-risco-valor').textContent = '—'; document.getElementById('prev-risco-cat').textContent = 'Preencha idade, PA, colesterol total, HDL e TFG.'; document.getElementById('prev-risco-cat').style.color = '#fbbf24'; document.getElementById('prev-risco-cat').style.borderColor = '#fbbf24'; document.getElementById('prev-conduta').textContent = ''; if (exportBtn) exportBtn.style.display = 'none'; return; }
          const risco = calcularRiscoAHA(idade, sexo, pas, colTotal, hdl, dm, tabaco, estatina, antiHiper, tfg);
          if (risco === null) { r.style.display = 'block'; document.getElementById('prev-risco-valor').textContent = '—'; document.getElementById('prev-risco-cat').textContent = 'PREVENT válida apenas para 30–79 anos.'; document.getElementById('prev-risco-cat').style.color = '#fbbf24'; document.getElementById('prev-risco-cat').style.borderColor = '#fbbf24'; document.getElementById('prev-conduta').textContent = ''; if (exportBtn) exportBtn.style.display = 'none'; return; }
          const metas = obterMetasPrevent(risco); const cor = metas.cor;
          r.style.display = 'block'; document.getElementById('prev-risco-valor').textContent = risco.toFixed(1) + '%'; document.getElementById('prev-risco-valor').style.color = cor; document.getElementById('prev-risco-cat').textContent = metas.cat; document.getElementById('prev-risco-cat').style.color = cor; document.getElementById('prev-risco-cat').style.borderColor = cor; document.getElementById('prev-conduta').textContent = `${metas.conduta} Meta LDL < ${metas.metaLDL} mg/dL e colesterol não-HDL < ${metas.metaNaoHDL} mg/dL.`; 
          if (exportBtn) exportBtn.style.display = 'block'; 
          r.dataset.risco = risco.toFixed(1); r.dataset.categoria = metas.cat; r.dataset.conduta = `Meta LDL < ${metas.metaLDL} mg/dL e colesterol não-HDL < ${metas.metaNaoHDL} mg/dL. ${metas.conduta}`;
        });
    }

    const preventClearBtn = document.getElementById('prevent-clear-btn');
    if(preventClearBtn) {
        preventClearBtn.addEventListener('click', () => { 
          document.querySelectorAll('#pane-prev input[type="number"]').forEach(el => el.value = ''); document.querySelectorAll('#pane-prev input[type="checkbox"]').forEach(el => el.checked = false); 
          document.getElementById('prevent-resultado').style.display = 'none'; 
          const btnExp = document.getElementById('prevent-export-btn'); if (btnExp) { btnExp.style.display = 'none'; btnExp.dataset.texto = ''; }
          const r = document.getElementById('prevent-resultado'); if(r) { r.dataset.risco = ''; r.dataset.categoria = ''; r.dataset.conduta = ''; }
        });
    }
  
    const preventExportBtn = document.getElementById('prevent-export-btn');
    if(preventExportBtn) {
        preventExportBtn.addEventListener('click', async () => { 
          const r = document.getElementById('prevent-resultado'); const textoProntuario = `》Avaliação de Risco Cardiovascular (PREVENT AHA 2023): ${r.dataset.risco}% em 10 anos.\n》Categoria: ${r.dataset.categoria}.\n》${r.dataset.conduta}`; 
          await enviarCondutaComConfirmacao({ type: 'PREVENT_INSERIR_CONDUTA', texto: textoProntuario }, textoProntuario);
        });
    }

    document.getElementById('ves-calc-btn').addEventListener('click', () => {
      let score = 0; score += parseInt(document.getElementById('ves-idade').value); score += parseInt(document.getElementById('ves-saude').value);
      const fisicas = document.querySelectorAll('.ves-fisica:checked').length; if (fisicas > 0) score += Math.min(fisicas, 2);
      const incapaz = document.querySelectorAll('.ves-incapaz:checked').length; if (incapaz > 0) score += 4;
      const r = document.getElementById('ves-resultado'); r.style.display = 'block'; let categoria, cor, conduta;
      if (score <= 2) { categoria = 'BAIXO RISCO (Robusto)'; cor = '#4ade80'; conduta = "Paciente classificado como idoso robusto (VES-13 = " + score + "). Orientada a manutenção de hábitos de vida saudáveis, prática regular de atividade física e alimentação balanceada. Retorno conforme rotina preventiva."; } else if (score <= 6) { categoria = 'MÉDIO RISCO (Risco de fragilização)'; cor = '#facc15'; conduta = "Paciente classificado com médio risco de vulnerabilidade/fragilização (VES-13 = " + score + "). Necessita de avaliação multidimensional mais detalhada para rastreio de síndromes geriátricas. Orientada prevenção de quedas, adequação do ambiente doméstico e revisão farmacoterapêutica. Retorno programado em curto/médio prazo para reavaliação contínua."; } else { categoria = 'ALTO RISCO (Frágil)'; cor = '#f87171'; conduta = "Paciente classificado como idoso frágil (VES-13 = " + score + "). Apresenta alta vulnerabilidade clínico-funcional. Plano focado em reabilitação, prevenção de iatrogenias, suporte ao cuidador e garantia de rede de apoio social. Sugerido acompanhamento compartilhado com equipe multidisciplinar e/ou encaminhamento à geriatria especializada. Retorno precoce estipulado para monitoramento de risco."; }
      document.getElementById('ves-risco-valor').textContent = score + ' pts'; document.getElementById('ves-risco-valor').style.color = cor; document.getElementById('ves-risco-cat').textContent = categoria; document.getElementById('ves-risco-cat').style.color = cor; document.getElementById('ves-risco-cat').style.borderColor = cor; document.getElementById('ves-conduta').textContent = conduta;
      const btnExp = document.getElementById('ves-export-btn'); if (btnExp) { btnExp.style.display = 'block'; btnExp.dataset.texto = `》AVALIAÇÃO DE VULNERABILIDADE (VES-13):\n- Pontuação: ${score}/10 pontos.\n- Classificação: ${categoria}.\n\n》PLANO TERAPÊUTICO:\n${conduta}`; }
    });

    const vesExportBtn = document.getElementById('ves-export-btn');
    if (vesExportBtn) vesExportBtn.addEventListener('click', async (e) => { await enviarCondutaComConfirmacao({ type: 'VES_INSERIR_CONDUTA', texto: e.target.dataset.texto }, e.target.dataset.texto); });

    document.getElementById('ves-clear-btn').addEventListener('click', () => { 
      document.getElementById('ves-idade').value = "0"; document.getElementById('ves-saude').value = "0"; document.querySelectorAll('#pane-ves input[type="checkbox"]').forEach(el => el.checked = false); 
      document.getElementById('ves-resultado').style.display = 'none'; const btnExp = document.getElementById('ves-export-btn'); if(btnExp) { btnExp.style.display = 'none'; btnExp.dataset.texto = ''; }
    });

    window.addEventListener('message', (event) => {
      if (!isTrustedSissonMessage(event)) return;
      const exports = { 
          'ADL_SUCESSO_EXPORTACAO': { id: 'adl-export-btn', color: '#166534' }, 
          'PUERI_CC_SUCESSO_EXPORTACAO': { id: 'export-unificado-btn', color: '#2563eb' }, 
          'VES_SUCESSO_EXPORTACAO': { id: 'ves-export-btn', color: '#7c3aed' }, 
          'PREVENT_SUCESSO_EXPORTACAO': { id: 'prevent-export-btn', color: '#2563eb' },
          'PN_SUCESSO_EXPORTACAO': { id: 'pn-export-btn', color: '#be185d' },
          'PAP_SUCESSO_EXPORTACAO': { id: 'prev-export-btn', color: '#be185d' } 
      };
      if (event.data && exports[event.data.type]) {
        const config = exports[event.data.type]; const btn = document.getElementById(config.id);
        if (btn) { const textoOriginal = btn.innerHTML; btn.innerHTML = '✅ Inserido no prontuário!'; btn.style.backgroundColor = '#059669'; setTimeout(() => { btn.innerHTML = textoOriginal; btn.style.backgroundColor = config.color; }, 3000); }
      }
    });

})();
