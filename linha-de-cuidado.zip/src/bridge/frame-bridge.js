(() => {
  const App = (window.PainelAPS = window.PainelAPS || {});
  const { SELECTORS, MESSAGE_TYPES } = App.constants;
  const { appendTextToField, allReachableDocuments, broadcastMessage, getFieldValue, getSissTargetOrigin, isTrustedSissonMessage, registrarAuditoria, setFormFieldValue } = App.utils;

  function getAvailableDocuments() {
    return allReachableDocuments(window);
  }

  // S01 FIX: origin dinâmica baseada no subdomínio real
  function postToTop(message) {
    try {
      window.top.postMessage(message, getSissTargetOrigin());
    } catch (error) {
      // sem ação; evita quebrar a extensão
    }
  }

  function normalizarCodigoProcedimento(codigo) {
    return String(codigo || '').replace(/\D/g, '');
  }

  function formatarCodigoProcedimento(codigo) {
    const limpo = normalizarCodigoProcedimento(codigo);
    if (!/^\d{10}$/.test(limpo)) return limpo;
    return limpo.replace(/(\d{2})(\d{2})(\d{2})(\d{3})(\d{1})/, '$1.$2.$3.$4-$5');
  }

  async function processarLancamentoISF(payload) {
    const condicaoIds = [
      ...(payload?.condicaoId ? [payload.condicaoId] : []),
      ...(Array.isArray(payload?.condicaoIds) ? payload.condicaoIds : []),
    ].filter(Boolean);
    const codigos = payload?.procedimentos || [];
    const encontrados = [];
    let naoEncontrados = [];

    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const documents = getAvailableDocuments();

    if (condicaoIds.length > 0) {
      for (const condicaoId of condicaoIds) {
        for (const doc of documents) {
          const checkbox = doc.getElementById(condicaoId);
          if (checkbox && !checkbox.checked) {
            checkbox.click();
            await delay(400);
            break;
          }
        }
      }
    }

    for (const codigoOriginal of codigos) {
      // REQUISITO 3: prefixo '*' indica que a marcação deve ser feita por texto,
      // não por número. O restante após o '*' é um fragmento a buscar na linha.
      const original = String(codigoOriginal || '').trim();
      const modoTexto = original.startsWith('*');

      if (modoTexto) {
        // Extrai o fragmento de texto a buscar. Aceita formatos:
        //   '*0301010064 - CONSULTA MEDICA EM ATENÇÃO PRIMÁRIA'
        //   '*CONSULTA MEDICA EM ATENÇÃO PRIMÁRIA'
        const semPrefixo = original.slice(1).trim();
        const aposHifen = semPrefixo.includes(' - ') ? semPrefixo.split(' - ').slice(1).join(' - ').trim() : semPrefixo;
        // Normaliza: tira acentos, caixa alta, colapsa espaços
        const normalizar = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
        const alvo = normalizar(aposHifen);
        if (!alvo) continue;

        let achou = false;
        for (const doc of documents) {
          const rows = doc.querySelectorAll('tr');
          for (const row of rows) {
            const conteudoNormalizado = normalizar(row.textContent || '');
            if (!conteudoNormalizado.includes(alvo)) continue;

            const checkbox = row.querySelector('input[type="checkbox"]');
            if (!checkbox) continue;

            if (!checkbox.checked) {
              checkbox.click();
              await delay(500);
            }

            const qtdInputs = row.querySelectorAll('input[type="text"]');
            for (const qtdInput of qtdInputs) {
              if (qtdInput.disabled || qtdInput.style.display === 'none' || qtdInput.classList.contains('autocomplete')) continue;
              setFormFieldValue(qtdInput, '1');
              break;
            }

            achou = true;
            encontrados.push(aposHifen);
            break;
          }
          if (achou) break;
        }

        if (!achou) naoEncontrados.push(aposHifen);
        continue;
      }

      const codigo = normalizarCodigoProcedimento(original);
      if (!codigo) continue;

      let achou = false;
      const codigoFormatado = formatarCodigoProcedimento(codigo);

      for (const doc of documents) {
        const rows = doc.querySelectorAll('tr');
        for (const row of rows) {
          if (!row.textContent.includes(codigo) && !row.textContent.includes(codigoFormatado)) continue;

          const checkbox = row.querySelector('input[type="checkbox"]');
          if (!checkbox) continue;

          if (!checkbox.checked) {
            checkbox.click();
            await delay(500);
          }

          const qtdInputs = row.querySelectorAll('input[type="text"]');
          for (const qtdInput of qtdInputs) {
            if (qtdInput.disabled || qtdInput.style.display === 'none' || qtdInput.classList.contains('autocomplete')) continue;
            setFormFieldValue(qtdInput, '1');
            break;
          }

          achou = true;
          encontrados.push(codigo);
          break;
        }
        if (achou) break;
      }

      if (!achou) naoEncontrados.push(codigo);
    }

    if (naoEncontrados.length > 0) {
      for (const codigoFaltante of naoEncontrados) {
        for (const doc of documents) {
          const input = doc.querySelector(SELECTORS.procedureSearchInput);
          if (!input) continue;

          input.focus();
          setFormFieldValue(input, codigoFaltante);
          input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Unidentified' }));
          await delay(1500);
          input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'ArrowDown', keyCode: 40, which: 40 }));
          await delay(300);
          input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 }));
          await delay(1500);
          break;
        }
      }

      const falhasReais = [];
      for (const codigo of naoEncontrados) {
        let achouAgora = false;
        const codigoFormatado = formatarCodigoProcedimento(codigo);

        for (const doc of documents) {
          const rows = doc.querySelectorAll('tr');
          for (const row of rows) {
            if (!row.textContent.includes(codigo) && !row.textContent.includes(codigoFormatado)) continue;

            const checkbox = row.querySelector('input[type="checkbox"]');
            if (!checkbox) continue;

            if (!checkbox.checked) {
              checkbox.click();
              await delay(300);
            }

            const qtdInputs = row.querySelectorAll('input[type="text"]');
            for (const qtdInput of qtdInputs) {
              if (qtdInput.disabled || qtdInput.style.display === 'none' || qtdInput.classList.contains('autocomplete')) continue;
              if (qtdInput.value !== '1') setFormFieldValue(qtdInput, '1');
              break;
            }

            achouAgora = true;
            break;
          }
          if (achouAgora) break;
        }

        if (achouAgora) encontrados.push(codigo);
        else falhasReais.push(codigo);
      }

      naoEncontrados = falhasReais;
    }

    // S07: Registrar auditoria do lançamento
    registrarAuditoria('ISF_LANCAMENTO', { encontrados, naoEncontrados });
    postToTop({ type: MESSAGE_TYPES.ISF_RESPOSTA_LANCAMENTO, encontrados, naoEncontrados });
  }

  function responderDadosPrevent() {
    const fields = {
      idade: SELECTORS.prevent.idade,
      sexo: SELECTORS.prevent.sexo,
      pas: SELECTORS.prevent.pas,
      textoExames: SELECTORS.prevent.textoExames,
    };

    const payload = {};
    for (const [key, selector] of Object.entries(fields)) {
      const element = document.querySelector(selector);
      if (element) payload[key] = getFieldValue(element);
    }

    if (Object.keys(payload).length > 0) {
      postToTop({ type: MESSAGE_TYPES.PREVENT_RESPOSTA_DADOS, payload });
    }
  }

  function responderDadosPreNatal() {
    const candidatos = [
      SELECTORS.prenatal?.dum,
      '[id="2038"]',
      'input[codigopergunta="2038"]',
      '#Questionario1_2038',
    ].filter(Boolean);

    let value = '';
    for (const seletor of candidatos) {
      const element = document.querySelector(seletor);
      value = getFieldValue(element);
      if (value) break;
    }

    if (value) {
      postToTop({ type: MESSAGE_TYPES.PN_RESPOSTA_DADOS, payload: { dum: value } });
    }
  }

  function inserirCondutaBasica(message) {
    const validTypes = [
      MESSAGE_TYPES.PREVENT_INSERIR_CONDUTA,
      MESSAGE_TYPES.VES_INSERIR_CONDUTA,
      MESSAGE_TYPES.ADL_INSERIR_CONDUTA,
      MESSAGE_TYPES.PN_INSERIR_CONDUTA,
      MESSAGE_TYPES.PAP_INSERIR_CONDUTA,
    ];

    if (!validTypes.includes(message.type)) return false;

    const field = document.querySelector(SELECTORS.evolution.plano);
    if (!field) return false;

    appendTextToField(field, message.texto);
    registrarAuditoria('INSERIR_CONDUTA', { tipo: message.type, textoResumo: String(message.texto).substring(0, 120) });
    const responseType = message.type.replace('INSERIR_CONDUTA', 'SUCESSO_EXPORTACAO');
    postToTop({ type: responseType });
    return true;
  }

  function inserirCondutaPuericultura(message) {
    if (message.type !== MESSAGE_TYPES.PUERI_CC_INSERIR_CONDUTA) return false;

    const avaliacaoField = document.querySelector(SELECTORS.evolution.avaliacao);
    const planoField = document.querySelector(SELECTORS.evolution.plano);

    let success = false;
    if (avaliacaoField && message.avaliacao) success = appendTextToField(avaliacaoField, message.avaliacao) || success;
    if (planoField && message.plano) success = appendTextToField(planoField, message.plano) || success;

    if (success) {
      registrarAuditoria('INSERIR_CONDUTA_PUERI', { avaliacao: String(message.avaliacao || '').substring(0, 80), plano: String(message.plano || '').substring(0, 80) });
      postToTop({ type: MESSAGE_TYPES.PUERI_CC_SUCESSO_EXPORTACAO });
    }
    return success;
  }

  window.addEventListener('message', (event) => {
    if (!isTrustedSissonMessage(event)) return;
    const message = event.data || {};

    if (message.type === MESSAGE_TYPES.PREVENT_PEDIR_DADOS) {
      responderDadosPrevent();
      return;
    }

    if (message.type === MESSAGE_TYPES.PN_PEDIR_DADOS) {
      responderDadosPreNatal();
      return;
    }

    if (inserirCondutaBasica(message)) return;
    if (inserirCondutaPuericultura(message)) return;

    if (message.type === MESSAGE_TYPES.ISF_LANCAR_PROCEDIMENTOS) {
      processarLancamentoISF(message.payload);
    }
  });
})();