(() => {
  const App = (window.PainelAPS = window.PainelAPS || {});

  App.templates = {
    getSidebarHtml() {
      return `
    <div id="clinic-header">
      <div>
        <div class="title">Painel Clínico APS</div>
        <div class="subtitle">Santo André</div>
      </div>
      <button id="clinic-close" title="Fechar">✕</button>
    </div>
    
    <div id="pane-home" class="clinic-tab-pane active">
      <div class="menu-linha-cuidado">
        <div class="lc-card" data-target="pane-pueri-cc">
          <div class="lc-icon">👶</div>
          <div class="lc-text">
            <div class="lc-title">Criança e Adolescente</div>
            <div class="lc-subtitle">Consulta de Puericultura e Curvas OMS</div>
          </div>
        </div>
        <div class="lc-card" data-target="pane-mulher">
          <div class="lc-icon">👩</div>
          <div class="lc-text">
            <div class="lc-title">Saúde da Mulher</div>
            <div class="lc-subtitle">Pré-Natal, Preventivo (Pap) e Datação</div>
          </div>
        </div>
        <div class="lc-card" data-target="pane-adulto">
          <div class="lc-icon">🩺</div>
          <div class="lc-text">
            <div class="lc-title">Adulto e Idoso</div>
            <div class="lc-subtitle">Checklist Clínico, IMC, Risco CV e VES-13</div>
          </div>
        </div>
      </div>
    </div>

    <div id="pane-mulher" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar ao Menu Principal</button>
      <h2 style="font-size: 14px; color: #1e293b; margin-bottom: 12px; padding: 0 4px; text-transform: uppercase;">👩 Saúde da Mulher</h2>
      <div class="dashboard-grid">
        <div class="dash-card" data-target="pane-prenatal">
          <div class="dash-icon">🤰</div>
          <div class="dash-title">Pré-Natal</div>
          <div class="dash-subtitle">Cálculo de IG e Condutas</div>
        </div>
        <div class="dash-card" data-target="pane-preventivo" style="background: #fdf2f8; border-color: #fbcfe8;">
          <div class="dash-icon">🌸</div>
          <div class="dash-title">Rastreamento CA de colo uterino</div>
          <div class="dash-subtitle">Rastreio Câncer de Colo</div>
        </div>
        <div class="dash-card" data-target="pane-tr-parceiro" style="background: #fff7ed; border-color: #fdba74;">
          <div class="dash-icon">🤝</div>
          <div class="dash-title">TR Parceiro</div>
          <div class="dash-subtitle">Testagem do parceiro da gestante</div>
        </div>
      </div>
    </div>

    <div id="pane-adulto" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar ao Menu Principal</button>
      <h2 style="font-size: 14px; color: #1e293b; margin-bottom: 12px; padding: 0 4px; text-transform: uppercase;">🩺 Adulto e Idoso</h2>
      <div class="dashboard-grid">
        <div class="dash-card" data-target="pane-adulto-clinica" style="grid-column: span 2; background: #eff6ff; border-color: #bfdbfe;">
          <div class="dash-icon">📋</div>
          <div class="dash-title">Avaliação Clínica Integrada</div>
          <div class="dash-subtitle">IMC, Checklist HAS/DM/Dislip e Rastreios</div>
        </div>
        <div class="dash-card" data-target="pane-prev">
          <div class="dash-icon">❤️</div>
          <div class="dash-title">Risco CV</div>
          <div class="dash-subtitle">Escore PREVENT</div>
        </div>
        <div class="dash-card" data-target="pane-ves">
          <div class="dash-icon">🧓</div>
          <div class="dash-title">Geriatria</div>
          <div class="dash-subtitle">Protocolo VES-13</div>
        </div>
      </div>
    </div>

    <div id="pane-adulto-clinica" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar</button>
      <button id="adl-auto-btn" class="prev-btn-auto" style="margin-bottom: 12px;">⚡ Auto-preencher Antropometria</button>
      
      <div class="pn-card">
        <h2 style="color: #1e293b;">Plano Terapêutico</h2>
        <div class="prev-section">1. ANTROPOMETRIA E NUTRIÇÃO</div>
        <div class="cc-grid">
          <div class="cc-field"><label>Peso (kg)</label><input type="number" id="adl-peso" placeholder="Ex: 80.5"></div>
          <div class="cc-field"><label>Altura (cm)</label><input type="number" id="adl-alt" placeholder="Ex: 175"></div>
        </div>
        <div style="font-size: 11px; margin-top: 6px; color: #475569; text-align: right; background: #f1f5f9; padding: 6px; border-radius: 6px;">
          IMC: <span id="adl-imc-display" style="font-weight:bold; font-size: 14px;">--</span>
        </div>

        <div class="prev-section" style="margin-top: 16px;">2. LINHAS DE CUIDADO ATIVAS</div>
        <p style="font-size:10.5px; color:#64748b; margin-bottom:8px; line-height: 1.3;">Marque as condições para gerar apoio visual de rastreio e o texto enxuto que será exportado ao prontuário.</p>
        
        <div class="prev-check"><input type="checkbox" id="chk-sem-comorb"><label for="chk-sem-comorb">Sem comorbidades</label></div>
        <div class="prev-check"><input type="checkbox" id="chk-has"><label for="chk-has">Hipertensão Arterial (HAS)</label></div>
        <div class="prev-check"><input type="checkbox" id="chk-dm"><label for="chk-dm">Diabetes Mellitus (DM)</label></div>
        <div class="prev-check"><input type="checkbox" id="chk-dislip"><label for="chk-dislip">Dislipidemia</label></div>
        <div id="adl-prevent-box" style="display:none; background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; padding:10px; margin-bottom:12px;">
            <div style="font-size:10.5px; font-weight:800; color:#0f766e; margin-bottom:8px;">❤️ DADOS PARA CÁLCULO DE RISCO CV (PREVENT)</div>
            <div style="font-size:10px; color:#475569; line-height:1.35; margin-bottom:8px;">Usar o PREVENT quando não houver doença cardiovascular prévia. Idade e sexo podem ser puxados automaticamente da página. Se houver evento isquêmico/doença aterosclerótica já estabelecida, o paciente é classificado automaticamente como muito alto risco.</div>
            <div class="cc-grid">
               <div class="cc-field"><label>Idade</label><input type="number" id="adl-prev-idade"></div>
               <div class="cc-field"><label>Sexo</label><select id="adl-prev-sexo"><option value="M">Masculino</option><option value="F">Feminino</option></select></div>
               <div class="cc-field"><label>PA Sistólica</label><input type="number" id="adl-prev-pas"></div>
               <div class="cc-field"><label>Col. Total</label><input type="number" id="adl-prev-col"></div>
               <div class="cc-field"><label>HDL</label><input type="number" id="adl-prev-hdl"></div>
               <div class="cc-field"><label>TFG</label><input type="number" id="adl-prev-tfg" placeholder="Ex: 90"></div>
            </div>
            <div class="prev-check" style="margin-top:8px; border-color:#fca5a5; background:#fef2f2;">
               <input type="checkbox" id="adl-prev-tabaco">
               <label for="adl-prev-tabaco" style="color:#991b1b; font-weight:bold;">Tabagismo Atual</label>
            </div>
            <div class="prev-check" style="margin-top:8px; border-color:#fecaca; background:#fef2f2;">
               <input type="checkbox" id="chk-evento-cv">
               <label for="chk-evento-cv" style="color:#991b1b; font-weight:600;">Evento isquêmico / doença cardiovascular prévia (IAM, AVC isquêmico, angina, revascularização)</label>
            </div>
            <button id="adl-prev-auto-btn" class="prev-btn-auto" style="margin-top:8px;">⚡ Puxar labs do prontuário</button>
            <div id="adl-auto-msg" style="font-size:10.5px; text-align:center; color:#16a34a; font-weight:bold; height:12px; margin-top:4px;"></div>
        </div>

        <div class="prev-actions">
          <button id="btn-gerar-plano-adulto" class="prev-btn-calc" style="background: #0284c7;">Gerar Plano Terapêutico</button>
        </div>
      </div>

      <div id="adl-resultado" style="display:none; margin-top: 12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px;">
        <div style="font-size:12px; font-weight:bold; color:#166534; border-bottom: 2px solid #bbf7d0; padding-bottom: 4px; margin-bottom: 8px;">📋 PLANO TERAPÊUTICO GERADO</div>
        
        <div style="font-size:10px; font-weight:bold; color:#15803d; margin-top:8px;">🥗 AVALIAÇÃO NUTRICIONAL</div>
        <p class="pueri-list" id="adl-res-nutri">--</p>
        
        <div style="font-size:10px; font-weight:bold; color:#15803d; margin-top:12px;">🔬 EXAMES DE RASTREIO (apenas visualização)</div>
        <p class="pueri-list" id="adl-res-exames" style="white-space: pre-wrap; color:#3f6212; opacity: 0.8; font-size:11px;">--</p>
        
        <div style="font-size:10px; font-weight:bold; color:#15803d; margin-top:12px;">🎯 METAS E ORIENTAÇÕES AO PACIENTE</div>
        <p class="pueri-list" id="adl-res-conduta" style="white-space: pre-wrap; font-size:12px; color:#166534; background:#dcfce7; padding:8px; border-radius:6px; margin-top:4px;">--</p>
        
        <button id="adl-export-btn" class="btn-export-global" style="background: #166534; margin-top: 12px;">✍️ Exportar METAS para a Evolução</button>

        <div id="adl-isf-section" style="display:none;">
            <div style="font-size:10px; font-weight:bold; color:#0f766e; margin-top:16px; border-top:1px dashed #86efac; padding-top:12px; text-align:center;">🎯 LANÇAMENTO RÁPIDO NO FATURAMENTO MS</div>
            <div id="adl-isf-actions" class="isf-grid" style="margin-top:8px; display:flex; flex-direction:column;"></div>
        </div>
      </div>
    </div>

    <div id="pane-isf" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar ao Menu Principal</button>
      <div id="isf-step-1" class="pn-card">
        <h2 style="color: #0f766e;">Lançamento Rápido (MS)</h2>
        <p style="font-size:11px; color:#64748b; margin-bottom:12px; line-height: 1.4;">Selecione o seu perfil profissional para carregar os procedimentos adequados:</p>
        <div class="isf-grid">
           <button class="isf-btn" id="btn-perfil-medico" style="font-size: 13px; padding: 16px;">👨‍⚕️ Médico</button>
           <button class="isf-btn" id="btn-perfil-enfermagem" style="font-size: 13px; padding: 16px;">👩‍⚕️ Enfermagem</button>
        </div>
      </div>
      <div id="isf-step-2" class="pn-card" style="display: none;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px;">
          <h2 id="isf-perfil-title" style="color: #0f766e; margin: 0; font-size: 14px;">Procedimentos</h2>
          <button id="btn-trocar-perfil" style="background: none; border: none; color: #3b82f6; font-size: 11px; cursor: pointer; font-weight: bold; text-decoration: underline; padding: 0;">Trocar Perfil</button>
        </div>
        <p style="font-size:11px; color:#64748b; margin-bottom:12px; line-height: 1.4;">Clique no indicador para marcar os procedimentos na tabela automaticamente.</p>
        <div class="isf-grid" id="isf-buttons-container"></div>
        <div id="isf-status">Pronto para lançar.</div>
      </div>
    </div>

    <div id="pane-prenatal" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar</button>
      <div class="pn-card">
        <h2>Cálculo de IG e Condutas MS</h2>
        <div class="pn-field"><label>Data da Última Menstruação (DUM)</label><input type="date" id="pn-dum"></div>
        <button id="pn-calc-btn" class="pn-btn-calc">Calcular IG e Ver Conduta</button>
      </div>
      <div id="pn-resultado" style="display:none;">
        <div class="pn-res-box"><div style="font-size:11px; font-weight:bold; letter-spacing:1px; color:#fbcfe8;">IDADE GESTACIONAL</div><div class="pn-res-ig" id="pn-ig-valor">--</div><div class="pn-res-dpp" id="pn-dpp-valor">DPP: --</div></div>
        <div id="pn-trim-box">
          <div class="pn-section-title" id="pn-trim-titulo">--</div>
          <div style="font-size:10px; font-weight:bold; color:#be185d; margin-top:8px;">🩺 CLÍNICA (O que avaliar)</div><p class="pn-list" id="pn-clinica">--</p>
          <div style="font-size:10px; font-weight:bold; color:#be185d; margin-top:12px;">🔬 EXAMES A SOLICITAR/CHECAR</div><p class="pn-list" id="pn-exames">--</p>
          <div style="font-size:10px; font-weight:bold; color:#be185d; margin-top:12px;">💊 CONDUTAS E PRESCRIÇÕES</div><p class="pn-list" id="pn-conduta">--</p>
        </div>
        
        <button id="pn-export-btn" class="btn-export-global" style="background: #be185d; margin-top: 12px;">✍️ Exportar Conduta para Evolução</button>

        <div style="margin-top:12px; background:#fff1f2; border:1px solid #fbcfe8; border-radius:8px; padding:10px;">
          <div style="font-size:10px; font-weight:bold; color:#9d174d; margin-bottom:6px;">🧪 TESTES RÁPIDOS REALIZADOS NA CONSULTA</div>
          <label for="pn-testes-rapidos" style="display:flex; gap:8px; align-items:flex-start; font-size:12px; color:#831843; cursor:pointer;">
            <input type="checkbox" id="pn-testes-rapidos" style="margin-top:2px;">
            <span>Incluir no lançamento de enfermagem os códigos de testes rápidos da gestante (HBsAg, HIV, Sífilis e Hepatite C).</span>
          </label>
        </div>

        <div style="font-size:10px; font-weight:bold; color:#9d174d; margin-top:16px; border-top:1px dashed #fbcfe8; padding-top:12px; text-align:center;">🎯 LANÇAMENTO RÁPIDO NO FATURAMENTO MS</div>
        <div class="isf-grid" style="margin-top:8px; display:flex; flex-direction:column;">
            <button class="isf-btn" id="pn-isf-medico" style="color:#be185d; border-color:#fbcfe8; background:#fdf2f8;">👨‍⚕️ Lançar Procedimentos (Médico)</button>
            <button class="isf-btn" id="pn-isf-enfermagem" style="color:#be185d; border-color:#fbcfe8; background:#fdf2f8;">👩‍⚕️ Lançar Procedimentos (Enfermagem)</button>
        </div>
      </div>
    </div>

    <div id="pane-preventivo" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar</button>
      <div class="pn-card" style="border-color: #fbcfe8;">
        <h2 style="color: #be185d;">Rastreamento CA de colo uterino</h2>
        
        <div class="prev-section" style="border-color:#fbcfe8; color:#9d174d;">1. DADOS DA PACIENTE</div>
        <div class="cc-grid">
           <div class="cc-field"><label>Idade Atual</label><input type="number" id="prev-idade-mulher" placeholder="Ex: 35"></div>
           <div class="cc-field"><label>Histórico de Exames</label>
             <select id="prev-hist-pap">
               <option value="1">1º Exame (ou não sabe/atrasado)</option>
               <option value="2">2º Exame (O anterior foi normal há 1 ano)</option>
               <option value="3">Rotina (Já possui 2 normais consecutivos)</option>
             </select>
           </div>
        </div>

        <div class="prev-section" style="border-color:#fbcfe8; color:#9d174d;">2. ANAMNESE E EXAME FÍSICO</div>
        <div class="prev-check"><input type="checkbox" id="prev-queixas"><label for="prev-queixas">Queixas (Corrimento, sangramento, prurido)</label></div>
        <div class="prev-check"><input type="checkbox" id="prev-colo-alt"><label for="prev-colo-alt">Colo alterado ao exame (friável, úlcera, lesão)</label></div>

        <div class="prev-section" style="border-color:#fbcfe8; color:#9d174d;">3. RESULTADO PRÉVIO DE PPN</div>
        <div class="cc-field" style="grid-column: span 2;">
          <select id="prev-resultado-pap" style="font-weight:bold;">
            <option value="normal">Negativo para Malignidade (Normal / Inflamatório)</option>
            <option value="ascus">ASC-US (Atipias de significado indeterminado)</option>
            <option value="lsil">LSIL (Lesão intraepitelial de baixo grau)</option>
            <option value="asch">ASC-H (Atipias não podendo afastar alto grau)</option>
            <option value="hsil">HSIL (Lesão intraepitelial de alto grau)</option>
            <option value="agc">AGC (Células glandulares atípicas)</option>
          </select>
        </div>

        <div class="prev-actions">
          <button id="btn-gerar-prev" class="prev-btn-calc" style="background: #be185d;">Gerar Conduta MS</button>
        </div>
      </div>

      <div id="prev-resultado-view" style="display:none; margin-top: 12px; background: #fdf2f8; border: 1px solid #fbcfe8; border-radius: 8px; padding: 12px;">
        <div style="font-size:12px; font-weight:bold; color:#831843; border-bottom: 2px solid #fbcfe8; padding-bottom: 4px; margin-bottom: 8px;">📋 CONDUTA E SEGUIMENTO</div>
        <div style="font-size:10px; font-weight:bold; color:#be185d; margin-top:8px;">RECOMENDAÇÃO MINISTÉRIO DA SAÚDE</div>
        <p class="pueri-list" id="prev-res-conduta" style="white-space: pre-wrap; font-size:12px; color:#831843;">--</p>
        
        <button id="prev-export-btn" class="btn-export-global" style="background: #be185d; margin-top: 12px;">✍️ Exportar Avaliação para Evolução</button>

        <div id="prev-isf-section" style="display:block;">
            <div style="font-size:10px; font-weight:bold; color:#be185d; margin-top:16px; border-top:1px dashed #fbcfe8; padding-top:12px; text-align:center;">🎯 LANÇAMENTO RÁPIDO NO FATURAMENTO MS</div>
            <div class="isf-grid" style="margin-top:8px; display:flex; flex-direction:column;">
                <button class="isf-btn" id="prev-isf-pap" style="color:#be185d; border-color:#fbcfe8; background:#fdf2f8;">🌸 Lançar Procedimentos (Coleta Citopatológico)</button>
            </div>
        </div>
      </div>
    </div>

    <div id="pane-tr-parceiro" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar</button>
      <div class="pn-card" style="border-color: #fdba74;">
        <h2 style="color: #c2410c;">TR Parceiro</h2>
        <p style="font-size:11px; color:#7c2d12; margin-bottom:12px; line-height:1.4;">Utilize esta aba para inserir rapidamente os procedimentos de testagem do parceiro ou parceria da gestante.</p>
        <div style="background:#fff7ed; border:1px solid #fdba74; border-radius:8px; padding:10px; font-size:11px; color:#7c2d12; line-height:1.5;">
          <div style="font-weight:800; color:#c2410c; margin-bottom:6px;">Códigos incluídos</div>
          <div>• 0214010287 - Anti-HIV em parceiro/parceria de gestante</div>
          <div>• 0214010260 - Sífilis em parceiro/parceria de gestante</div>
          <div>• 0214010317 - Hepatite C em parceiro/parceria de gestante</div>
          <div>• 0214010244 - HBsAg em parceiro/parceria de gestante</div>
        </div>
        <button id="tr-parceiro-isf-btn" class="isf-btn" style="margin-top:12px; color:#c2410c; border-color:#fdba74; background:#fff7ed;">🤝 Lançar Procedimentos TR Parceiro</button>
      </div>
    </div>

    <div id="pane-pueri-cc" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar ao Menu Principal</button>
      
      <button id="btn-pueri-iniciar-auto" class="prev-btn-auto" style="margin-bottom: 12px; background: #0d9488; color: white; border: none; padding: 12px; font-size: 13px; font-weight: bold; box-shadow: 0 4px 6px rgba(13, 148, 136, 0.2);">⚡ Iniciar Consulta Automática (1 Clique)</button>

      <div class="cc-card">
        <h2>Dados da Criança</h2>
        <div class="pueri-field" style="margin-bottom: 12px;">
          <label>Roteiro da Consulta (Idade para DNPM/Vacinas)</label>
          <select id="pueri-idade">
            <option value="">-- Selecione --</option>
            <option value="15d">1ª Semana a 15 Dias</option>
            <option value="1m">1 Mês</option>
            <option value="2m">2 Meses</option>
            <option value="3m">3 Meses</option>
            <option value="4m">4 Meses</option>
            <option value="5m">5 Meses</option>
            <option value="6m">6 Meses</option>
            <option value="7m">7 Meses</option>
            <option value="8m">8 Meses</option>
            <option value="9m">9 Meses</option>
            <option value="10m">10 Meses</option>
            <option value="11m">11 Meses</option>
            <option value="12m">12 Meses (1 Ano)</option>
            <option value="13m">13 Meses (1 Ano e 1 Mês)</option>
            <option value="14m">14 Meses (1 Ano e 2 Meses)</option>
            <option value="15m">15 Meses (1 Ano e 3 Meses)</option>
            <option value="16m">16 Meses (1 Ano e 4 Meses)</option>
            <option value="17m">17 Meses (1 Ano e 5 Meses)</option>
            <option value="18m">18 Meses (1 Ano e 6 Meses)</option>
            <option value="19m">19 Meses (1 Ano e 7 Meses)</option>
            <option value="20m">20 Meses (1 Ano e 8 Meses)</option>
            <option value="21m">21 Meses (1 Ano e 9 Meses)</option>
            <option value="22m">22 Meses (1 Ano e 10 Meses)</option>
            <option value="23m">23 Meses (1 Ano e 11 Meses)</option>
            <option value="24m">24 Meses (2 Anos)</option>
            <option value=">2a">Maior de 2 anos (2 a 5 anos) - Apenas Curvas OMS</option>
          </select>
        </div>

        <div id="pueri-resultado" style="display:none; margin-bottom: 16px; background: #f0fdfa; border: 1px solid #ccfbf1; border-radius: 8px; padding: 12px;">
          <div class="pueri-section-title" id="pueri-titulo">--</div>
          <div style="font-size:10px; font-weight:bold; color:#0d9488; margin-top:8px;">🧠 MARCOS DO DESENVOLVIMENTO (DNPM)</div><p class="pueri-list" id="pueri-dnpm">--</p>
          <div style="font-size:10px; font-weight:bold; color:#dc2626; margin-top:12px;">🚨 SINAIS DE ALARME (Encaminhar/Investigar)</div><p class="pueri-list" style="color:#991b1b;" id="pueri-alerta">--</p>
          <div style="font-size:10px; font-weight:bold; color:#0d9488; margin-top:12px;">💉 VACINAS (Calendário Acumulado)</div><p class="pueri-list" style="white-space: pre-wrap;" id="pueri-vacina">--</p>
          <div style="font-size:10px; font-weight:bold; color:#0d9488; margin-top:12px;">🍼 ALIMENTAÇÃO</div><p class="pueri-list" id="pueri-dieta">--</p>
          <div style="font-size:10px; font-weight:bold; color:#0d9488; margin-top:12px;">💊 CONDUTAS E SUPLEMENTAÇÃO</div><p class="pueri-list" id="pueri-conduta">--</p>
        </div>

        <div class="cc-grid">
          <div class="cc-field cc-full"><label>Sexo</label><select id="cc-sexo"><option value="">Selecione</option><option value="M">Masculino</option><option value="F">Feminino</option></select></div>
          <div class="cc-field"><label>Idade — Anos</label><input type="number" id="cc-anos" min="0" max="5" placeholder="ex: 2"></div>
          <div class="cc-field"><label>Idade — Meses</label><input type="number" id="cc-mex" min="0" max="11" placeholder="ex: 4"></div>
          <div class="cc-field"><label>Peso (kg)</label><input type="number" id="cc-peso" step="0.1" placeholder="ex: 12.5"></div>
          <div class="cc-field"><label>Altura (cm)</label><input type="number" id="cc-alt" step="0.1" placeholder="ex: 86.0"></div>
          <div class="cc-field cc-full"><label>Perímetro Cefálico (cm) — opcional</label><input type="number" id="cc-pc" step="0.1" placeholder="ex: 47.5"></div>
        </div>
        <div class="cc-btns" style="margin-top:16px">
          <button class="cc-btn cc-btn-auto" id="cc-auto" title="Extrair dados">Puxar Manual</button>
          <button class="cc-btn cc-btn-calc" id="cc-calcular-unificado">Calcular Consulta Completa</button>
          <button class="cc-btn cc-btn-limpar" id="cc-limpar-unificado">Limpar</button>
        </div>
      </div>

      <div id="resumo-unificado" style="display:none;">
        <div class="cc-card cc-resumo" id="cc-resumo" style="display:none; border: 1px solid #93c5fd; background: #eff6ff;">
          <div class="cc-resumo-header"><h3>Resumo Antropométrico (OMS)</h3></div>
          <table class="cc-table"><thead><tr><th>Parâmetro</th><th>Valor</th><th>Escore-Z</th><th>Classificação</th></tr></thead><tbody id="cc-rtb"></tbody></table>
        </div>
        <div class="cc-charts" id="cc-charts" style="display:none;">
          <div class="cc-charts-grid">
            <div class="cc-chart-card"><h4>Peso / Idade</h4><div class="cc-chart-meta" id="cc-mPI"></div><div class="cc-chart-wrap"><canvas class="cc-chart-canvas" id="cc-cPI"></canvas><span class="cc-chart-point" id="cc-dot-PI"></span></div><div class="cc-chart-badge" id="cc-bPI"></div></div>
            <div class="cc-chart-card"><h4>Altura / Idade</h4><div class="cc-chart-meta" id="cc-mAI"></div><div class="cc-chart-wrap"><canvas class="cc-chart-canvas" id="cc-cAI"></canvas><span class="cc-chart-point" id="cc-dot-AI"></span></div><div class="cc-chart-badge" id="cc-bAI"></div></div>
            <div class="cc-chart-card"><h4>IMC / Idade</h4><div class="cc-chart-meta" id="cc-mIMC"></div><div class="cc-chart-wrap"><canvas class="cc-chart-canvas" id="cc-cIMC"></canvas><span class="cc-chart-point" id="cc-dot-IMC"></span></div><div class="cc-chart-badge" id="cc-bIMC"></div></div>
            <div class="cc-chart-card" id="cc-pc-card"><h4>Perím. Cefálico / Idade</h4><div class="cc-chart-meta" id="cc-mPC"></div><div class="cc-chart-wrap"><canvas class="cc-chart-canvas" id="cc-cPC"></canvas><span class="cc-chart-point" id="cc-dot-PC"></span></div><div class="cc-chart-badge" id="cc-bPC"></div></div>
          </div>
        </div>
        <button id="export-unificado-btn" class="btn-export-global" style="margin-top: 16px; background: #0f766e;" data-avaliacao="" data-plano="">✍️ Exportar Avaliação OMS e Plano</button>
        
        <div id="pueri-isf-section" style="display:none; margin-top: 16px;">
            <div style="font-size:10px; font-weight:bold; color:#0f766e; border-top:1px dashed #99f6e4; padding-top:12px; text-align:center;">🎯 LANÇAMENTO RÁPIDO NO FATURAMENTO MS</div>
            <div class="isf-grid" style="margin-top:8px; display:flex; flex-direction:column;">
                <button class="isf-btn" id="pueri-isf-medico" style="color:#0f766e; border-color:#99f6e4; background:#f0fdfa;">👨‍⚕️ Lançar Procedimentos (Médico)</button>
                <button class="isf-btn" id="pueri-isf-enfermagem" style="color:#0f766e; border-color:#99f6e4; background:#f0fdfa;">👩‍⚕️ Lançar Procedimentos (Enfermagem)</button>
            </div>
        </div>

        <button id="cc-print-btn" class="btn-export-global cc-btn-print" style="background-color: #475569; margin-top:12px;">🖨️ Imprimir Gráficos e Roteiro</button>
      </div>
    </div>

    <div id="pane-prev" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar</button>
      <button id="prevent-auto-btn" class="prev-btn-auto">⚡ Auto-preencher da página</button>
      <div id="prevent-auto-msg"></div>
      <div class="prev-section">DADOS DO PACIENTE</div>
      <div class="prev-row"><label>Idade</label><input type="number" id="prev-idade"></div>
      <div class="prev-row"><label>Sexo</label><select id="prev-sexo"><option value="M">Masculino</option><option value="F">Feminino</option></select></div>
      <div class="prev-section">EXAME FÍSICO E LABS</div>
      <div class="prev-row"><label>PA Sistólica</label><input type="number" id="prev-pas"></div>
      <div class="prev-row"><label>Colesterol Total</label><input type="number" id="prev-colTotal"></div>
      <div class="prev-row"><label>HDL</label><input type="number" id="prev-hdl"></div>
      <div class="prev-row"><label>TFG estimada</label><input type="number" id="prev-tfg"></div>
      <div class="prev-section">FATORES DE RISCO</div>
      <div class="prev-check"><input type="checkbox" id="prev-dm"><label for="prev-dm">Diabetes mellitus</label></div>
      <div class="prev-check"><input type="checkbox" id="prev-tabaco"><label for="prev-tabaco">Tabagismo atual</label></div>
      <div class="prev-check" style="border-color:#fecaca; background:#fef2f2;"><input type="checkbox" id="prev-evento-cv"><label for="prev-evento-cv" style="color:#991b1b; font-weight:600;">Evento isquêmico / doença cardiovascular prévia</label></div>
      <div class="prev-section">MEDICAÇÕES EM USO</div>
      <div class="prev-check"><input type="checkbox" id="prev-estatina"><label for="prev-estatina">Estatina</label></div>
      <div class="prev-check"><input type="checkbox" id="prev-antihiper"><label for="prev-antihiper">Anti-hipertensivo</label></div>
      <div class="prev-actions"><button id="prevent-calc-btn" class="prev-btn-calc">CALCULAR RISCO</button><button id="prevent-clear-btn" class="prev-btn-clear">Limpar</button></div>
      <div id="prevent-resultado" style="display:none;">
        <div id="prevent-resultado-inner">
          <div class="prev-res-label">RISCO EM 10 ANOS</div><div id="prev-risco-valor">—</div><div id="prev-risco-cat">—</div>
          <div class="prev-res-label" style="margin-top:10px;">CONDUTA SUGERIDA</div><div id="prev-conduta"></div>
          <button id="prevent-export-btn" class="btn-export-global" style="display:none;">✍️ Exportar para Evolução</button>
        </div>
      </div>
    </div>

    <div id="pane-ves" class="clinic-tab-pane">
      <button class="btn-voltar-menu">⬅ Voltar</button>
      <div class="prev-section">1. IDADE</div><select id="ves-idade"><option value="0">60 a 74 anos (0 pt)</option><option value="1">75 a 84 anos (1 pt)</option><option value="3">85 anos ou mais (3 pts)</option></select>
      <div class="prev-section">2. AUTOPERCEPÇÃO DA SAÚDE</div><div style="font-size:11.5px; color:#000000; font-weight:700; margin-bottom:8px;">Comparado a pessoas da mesma idade:</div><select id="ves-saude"><option value="0">Excelente, Muito Boa ou Boa (0 pt)</option><option value="1">Regular ou Ruim (1 pt)</option></select>
      <div class="prev-section">3. LIMITAÇÃO FÍSICA (Máx 2 pts)</div><div style="font-size:11.5px; color:#000000; font-weight:700; margin-bottom:8px;">Tem MUITA dificuldade ou é INCAPAZ de:</div>
      <div class="prev-check"><input type="checkbox" class="ves-fisica" id="v1"><label for="v1">Curvar-se, agachar ou ajoelhar-se</label></div><div class="prev-check"><input type="checkbox" class="ves-fisica" id="v2"><label for="v2">Levantar/carregar objetos (aprox 5kg)</label></div><div class="prev-check"><input type="checkbox" class="ves-fisica" id="v3"><label for="v3">Elevar braços acima do ombro</label></div><div class="prev-check"><input type="checkbox" class="ves-fisica" id="v4"><label for="v4">Escrever ou manusear pequenos objetos</label></div><div class="prev-check"><input type="checkbox" class="ves-fisica" id="v5"><label for="v5">Caminhar 400 metros</label></div><div class="prev-check"><input type="checkbox" class="ves-fisica" id="v6"><label for="v6">Fazer trabalho doméstico pesado</label></div>
      <div class="prev-section">4. INCAPACIDADES (Máx 4 pts)</div><div style="font-size:11.5px; color:#000000; font-weight:700; margin-bottom:8px;">Por causa da saúde, DEIXOU de fazer ou RECEBE AJUDA para:</div>
      <div class="prev-check"><input type="checkbox" class="ves-incapaz" id="i1"><label for="i1">Fazer compras de itens pessoais</label></div><div class="prev-check"><input type="checkbox" class="ves-incapaz" id="i2"><label for="i2">Lidar com dinheiro / pagar contas</label></div><div class="prev-check"><input type="checkbox" class="ves-incapaz" id="i3"><label for="i3">Caminhar dentro de casa</label></div><div class="prev-check"><input type="checkbox" class="ves-incapaz" id="i4"><label for="i4">Tarefas domésticas leves</label></div><div class="prev-check"><input type="checkbox" class="ves-incapaz" id="i5"><label for="i5">Tomar banho de chuveiro ou banheira</label></div>
      <div class="prev-actions"><button id="ves-calc-btn" class="prev-btn-calc">CALCULAR VES-13</button><button id="ves-clear-btn" class="prev-btn-clear">Limpar</button></div>
      <div id="ves-resultado" style="display:none; margin-top: 14px; border-radius: 8px; overflow: hidden; border: 1px solid #312e81;">
        <div style="background: #111827; padding: 14px; text-align: center;">
          <div class="prev-res-label">PONTUAÇÃO TOTAL</div><div id="ves-risco-valor" style="font-size: 40px; font-weight: 800; margin: 4px 0;">—</div><div id="ves-risco-cat" style="display: inline-block; font-size: 13px; font-weight: 700; padding: 3px 14px; border-radius: 20px; border: 2px solid; margin: 4px 0 8px;">—</div>
          <div class="prev-res-label" style="margin-top:10px;">PLANO TERAPÊUTICO</div><div id="ves-conduta" style="font-size: 10.5px; color: #a5b4fc; line-height: 1.5; margin-top: 6px; text-align: left;"></div>
          <button id="ves-export-btn" class="btn-export-global" style="display:none;">✍️ Exportar para Evolução</button>
        </div>
      </div>
    </div>
  `;
    },
  };
})();