(() => {
  const App = (window.PainelAPS = window.PainelAPS || {});

  App.constants = {
    HOST_FRAGMENT: 'sissonline.com.br',
    IDS: {
      sidebar: 'clinic-sidebar',
      toggle: 'clinic-toggle',
    },
    SELECTORS: {
      prevent: {
        idade: '#IdentificadorUsuario_lblAgeFilledClone',
        sexo: '#IdentificadorUsuario_lblSexFilled',
        sexoClone: '#IdentificadorUsuario_lblSexFilledClone',
        pas: '[id="2005"]',
        textoExames: '[id="2028"]',
      },
      prenatal: {
        dum: '[id="2038"]',
      },
      evolution: {
        avaliacao: '[id="2033"]',
        plano: '[id="4225"]',
      },
      anthropometry: {
        peso: 'input[codigopergunta="1996"]',
        altura: 'input[codigopergunta="1997"]',
        pc: 'input[codigopergunta="2322"]',
      },
      procedureSearchInput: '#Questionario1_ucProducaoAmbulatorial_txtProcedimento',
    },
    MESSAGE_TYPES: {
      PREVENT_PEDIR_DADOS: 'PREVENT_PEDIR_DADOS',
      PREVENT_RESPOSTA_DADOS: 'PREVENT_RESPOSTA_DADOS',
      PN_PEDIR_DADOS: 'PN_PEDIR_DADOS',
      PN_RESPOSTA_DADOS: 'PN_RESPOSTA_DADOS',
      PREVENT_INSERIR_CONDUTA: 'PREVENT_INSERIR_CONDUTA',
      VES_INSERIR_CONDUTA: 'VES_INSERIR_CONDUTA',
      ADL_INSERIR_CONDUTA: 'ADL_INSERIR_CONDUTA',
      PN_INSERIR_CONDUTA: 'PN_INSERIR_CONDUTA',
      PAP_INSERIR_CONDUTA: 'PAP_INSERIR_CONDUTA',
      PUERI_CC_INSERIR_CONDUTA: 'PUERI_CC_INSERIR_CONDUTA',
      ISF_LANCAR_PROCEDIMENTOS: 'ISF_LANCAR_PROCEDIMENTOS',
      ISF_RESPOSTA_LANCAMENTO: 'ISF_RESPOSTA_LANCAMENTO',
      ADL_SUCESSO_EXPORTACAO: 'ADL_SUCESSO_EXPORTACAO',
      PUERI_CC_SUCESSO_EXPORTACAO: 'PUERI_CC_SUCESSO_EXPORTACAO',
      VES_SUCESSO_EXPORTACAO: 'VES_SUCESSO_EXPORTACAO',
      PREVENT_SUCESSO_EXPORTACAO: 'PREVENT_SUCESSO_EXPORTACAO',
      PN_SUCESSO_EXPORTACAO: 'PN_SUCESSO_EXPORTACAO',
      PAP_SUCESSO_EXPORTACAO: 'PAP_SUCESSO_EXPORTACAO',
    },
    EXPORT_EVENT_MAP: {
      ADL_SUCESSO_EXPORTACAO: { id: 'adl-export-btn', color: '#166534' },
      PUERI_CC_SUCESSO_EXPORTACAO: { id: 'export-unificado-btn', color: '#2563eb' },
      VES_SUCESSO_EXPORTACAO: { id: 'ves-export-btn', color: '#7c3aed' },
      PREVENT_SUCESSO_EXPORTACAO: { id: 'prevent-export-btn', color: '#2563eb' },
      PN_SUCESSO_EXPORTACAO: { id: 'pn-export-btn', color: '#be185d' },
      PAP_SUCESSO_EXPORTACAO: { id: 'prev-export-btn', color: '#be185d' },
    },
    RAPID_TEST_PROCEDURES: {
      gestante: [
        '0214010236 - TESTE RÁPIDO PARA DETECÇÃO DO ANTÍGENO DE SUPERFÍCIE DO VÍRUS DA HEPATITE B - HBV (HBSAG) EM GESTANTE',
        '0214010279 - TESTE RÁPIDO PARA DETECÇÃO DE ANTICORPOS ANTI-HIV EM GESTANTE',
        '0214010252 - TESTE RÁPIDO TREPONÊMICO (SÍFILIS) EM GESTANTE',
        '0214010309 - TESTE RÁPIDO PARA DETECÇÃO DE ANTICORPOS CONTRA O VÍRUS DA HEPATITE C EM GESTANTE',
      ],
      parceiroGestante: [
        '0214010287 - TESTE RÁPIDO PARA DETECÇÃO DE ANTICORPOS ANTI-HIV EM PARCEIRO OU PARCERIA DE GESTANTE',
        '0214010260 - TESTE RÁPIDO TREPONÊMICO (SÍFILIS) EM PARCEIRO OU PARCERIA DE GESTANTE',
        '0214010317 - TESTE RÁPIDO PARA DETECÇÃO DE ANTICORPOS CONTRA O VÍRUS DA HEPATITE C EM PARCEIRO OU PARCERIA DE GESTANTE',
        '0214010244 - TESTE RÁPIDO PARA DETECÇÃO DO ANTÍGENO DE SUPERFÍCIE DO VÍRUS DA HEPATITE B (HBV) (HBSAG) EM PARCEIRO OU PARCERIA DE GESTANTE',
      ],
    },
    ISF_CODES: {
      medico: {
        gestante: { condicaoId: '1994_2860', procedimentos: ['0101040083', '0101040075', '0301100039', '0301010110'], label: '🤰 Gestante' },
        puericultura: { condicaoId: '2030_2932', procedimentos: ['0101040083', '0101040075', '0301010269', '0301010277', '*0301010064 - CONSULTA MEDICA EM ATENÇÃO PRIMÁRIA'], label: '👶 Puericultura' },
        diabetes: { condicaoId: '2030_2924', procedimentos: ['0301100039', '0101040083', '0101040075', '0301040095', '*0301010064 - CONSULTA CLÍNICA (NOVO)'], label: '🩸 Diabetes' },
        hipertensao: { condicaoId: '2030_2928', procedimentos: ['0301100039', '0101040083', '0101040075', '*0301010064 - CONSULTA CLÍNICA (NOVO)'], label: '❤️ Hipertensão' },
        idoso: { procedimentos: ['0101040083', '0101040075'], label: '🧓 Pessoa Idosa' },
      },
      enfermagem: {
        gestante: { condicaoId: '1994_2860', procedimentos: ['0101040083', '0101040075', '0301100039', '0301010110'], label: '🤰 Gestante' },
        puericultura: { condicaoId: '2030_2932', procedimentos: ['0101040083', '0101040075', '0301010269', '0301010277', '0301010030 - CONSULTA DE PROFISSIONAIS DE NÍVEL SUPERIOR NA ATENÇÃO PRIMÁRIA (EXCETO MÉDICO)'], label: '👶 Puericultura' },
        diabetes: { condicaoId: '2030_2924', procedimentos: ['0301100039', '0101040083', '0101040075', '0301040095'], label: '🩸 Diabetes' },
        hipertensao: { condicaoId: '2030_2928', procedimentos: ['0301100039', '0101040083', '0101040075'], label: '❤️ Hipertensão' },
        idoso: { procedimentos: ['0101040083', '0101040075'], label: '🧓 Pessoa Idosa' },
        mulher: { condicaoIds: ['2030_2939', '2030_2935'], procedimentos: ['0201020033'], label: '🌸 Rastreamento CA colo uterino' },
      },
    },
  };
  // G01 FIX: Congelar constantes para impedir sobrescrita por scripts de terceiros
  Object.freeze(App.constants);
  Object.freeze(App.constants.IDS);
  Object.freeze(App.constants.SELECTORS);
  Object.freeze(App.constants.MESSAGE_TYPES);
})();