(() => {
  const App = (window.PainelAPS = window.PainelAPS || {});
  const { HOST_FRAGMENT } = App.constants;

  // ── S01/S02 FIX: Origens confiáveis baseadas no HOST_FRAGMENT ──
  // O SISS usa subdomínios variáveis (ex: santoandre-ambulatorial.sissonline.com.br)
  // por isso não é possível fixar uma origin estática.

  function isSissOrigin(origin) {
    if (typeof origin !== 'string' || !origin) return false;
    try {
      const url = new URL(origin);
      return url.hostname === HOST_FRAGMENT || url.hostname.endsWith('.' + HOST_FRAGMENT);
    } catch (e) {
      return false;
    }
  }

  // Origem dinâmica: usa a origin da própria janela (que já é SISS)
  function getSissTargetOrigin() {
    try {
      if (isSissOrigin(window.location.origin)) return window.location.origin;
    } catch (e) { /* ignore */ }
    return 'https://sissonline.com.br'; // fallback
  }

  function isTrustedSissonMessage(event) {
    if (!event || !event.data || typeof event.data !== 'object') return false;
    // S02 FIX: origin 'null' NÃO é mais aceito — removido
    if (typeof event.origin !== 'string') return false;
    return isSissOrigin(event.origin);
  }

  // ── S03 FIX: Utilitário de escaping HTML ──
  function escapeHtml(str) {
    if (typeof str !== 'string') return String(str ?? '');
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // S01 FIX: origin dinâmica baseada no domínio real do SISS, nunca '*'
  function broadcastMessage(targetWindow, message, origin) {
    const safeOrigin = origin || getSissTargetOrigin();
    try {
      targetWindow.postMessage(message, safeOrigin);
    } catch (error) {
      // evita quebrar a interface quando um frame não está acessível
    }

    let frameCount = 0;
    try {
      frameCount = targetWindow.frames.length;
    } catch (error) {
      frameCount = 0;
    }

    for (let index = 0; index < frameCount; index += 1) {
      try {
        broadcastMessage(targetWindow.frames[index], message, safeOrigin);
      } catch (error) {
        // frame bloqueado, apenas segue
      }
    }
  }

  function allReachableDocuments(rootWindow = window) {
    const docs = [];
    const visited = new Set();

    function walk(win) {
      if (!win || visited.has(win)) return;
      visited.add(win);

      try {
        if (win.document) docs.push(win.document);
      } catch (error) {
        return;
      }

      let frameCount = 0;
      try {
        frameCount = win.frames.length;
      } catch (error) {
        frameCount = 0;
      }

      for (let index = 0; index < frameCount; index += 1) {
        try {
          walk(win.frames[index]);
        } catch (error) {
          // ignora frame inacessível
        }
      }
    }

    walk(rootWindow);
    return docs;
  }

  function findElementDeep(selector, rootWindow = window) {
    const documents = allReachableDocuments(rootWindow);
    for (const doc of documents) {
      try {
        const element = doc.querySelector(selector);
        if (element) return element;
      } catch (error) {
        // seletor inválido ou documento inacessível
      }
    }
    return null;
  }

  function getFieldValue(element) {
    if (!element) return '';
    if (typeof element.value === 'string' && element.value.trim() !== '') return element.value;
    return (
      element.getAttribute('value') ||
      element.getAttribute('padrao') ||
      element.getAttribute('informacaoanterior') ||
      (typeof element.textContent === 'string' ? element.textContent.trim() : '') ||
      ''
    );
  }

  function parseBRNumber(value) {
    if (value === null || value === undefined || value === '') return NaN;
    const cleaned = String(value).replace(',', '.').replace(/[^\d.-]/g, '');
    return Number.parseFloat(cleaned);
  }

  function setFormFieldValue(element, value) {
    if (!element) return false;
    element.value = value;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function appendTextToField(element, text) {
    if (!element || !text) return false;
    const currentText = element.value === '.' ? '' : (element.value || '');
    element.value = currentText + (currentText ? '\n\n' : '') + text;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  // ── S07 FIX: Sistema de logging de auditoria ──
  const LOG_STORAGE_KEY = 'painelAPS_auditLog';
  const MAX_LOG_ENTRIES = 500;

  async function registrarAuditoria(acao, detalhes) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        // fallback: log no console se chrome.storage não estiver disponível
        console.info('[PainelAPS Auditoria]', new Date().toISOString(), acao, detalhes);
        return;
      }
      const result = await chrome.storage.local.get(LOG_STORAGE_KEY);
      const logs = Array.isArray(result[LOG_STORAGE_KEY]) ? result[LOG_STORAGE_KEY] : [];
      logs.push({
        ts: new Date().toISOString(),
        acao,
        detalhes: typeof detalhes === 'string' ? detalhes : JSON.stringify(detalhes),
        url: window.location.href.substring(0, 120),
      });
      // manter apenas os últimos MAX_LOG_ENTRIES registros
      if (logs.length > MAX_LOG_ENTRIES) logs.splice(0, logs.length - MAX_LOG_ENTRIES);
      await chrome.storage.local.set({ [LOG_STORAGE_KEY]: logs });
    } catch (error) {
      // falha no logging não deve quebrar a extensão
      console.warn('[PainelAPS] Falha ao registrar auditoria:', error);
    }
  }

  // ── G04 FIX: Healthcheck de seletores no boot ──
  // Busca em todos os frames acessíveis (os seletores do SISS vivem em iframes)
  function verificarSeletoresCriticos(seletores) {
    const ausentes = [];
    const criticos = [
      { nome: 'Idade do paciente', sel: seletores.prevent?.idade },
      { nome: 'Sexo do paciente', sel: seletores.prevent?.sexo },
    ];
    for (const item of criticos) {
      if (item.sel && !findElementDeep(item.sel, window)) {
        ausentes.push(item.nome);
      }
    }
    return ausentes;
  }

  App.utils = {
    allReachableDocuments,
    appendTextToField,
    broadcastMessage,
    escapeHtml,
    findElementDeep,
    getFieldValue,
    getSissTargetOrigin,
    isTrustedSissonMessage,
    parseBRNumber,
    registrarAuditoria,
    setFormFieldValue,
    verificarSeletoresCriticos,
  };
})();