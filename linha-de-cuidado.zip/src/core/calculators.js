(() => {
  const App = (window.PainelAPS = window.PainelAPS || {});

    function getKeys(d) { return Object.keys(d).map(Number).sort((a,b)=>a-b); }
  
    function interp(d, m) { 
        if (d[m]) return d[m]; 
        const ks = getKeys(d); 
        let lo = null, hi = null; 
        for (const k of ks) { if (k <= m) lo = k; } 
        for (const k of ks) { if (k >= m) { hi = k; break; } } 
        if (lo === null) return d[ks[0]]; 
        if (hi === null) return d[ks[ks.length-1]]; 
        if (lo === hi) return d[lo]; 
        const t = (m-lo)/(hi-lo); 
        return d[lo].map((v,i) => v + t*(d[hi][i]-v)); 
    }
  
    function calcZScore(val, arr) { 
        const p50 = arr[3]; 
        const sd_pos = (arr[6] - arr[3]) / 1.8808; 
        const sd_neg = (arr[3] - arr[0]) / 1.8808; 
        let z = 0; 
        if (val > p50) z = (val - p50) / sd_pos; 
        else if (val < p50) z = (val - p50) / sd_neg; 
        return z > 0 ? '+' + z.toFixed(2) : z.toFixed(2); 
    }
  
    function getZClass(zStr, tipo) { 
        const z = parseFloat(zStr); 
        if (tipo === 'pc') { 
            if (z < -2) return { c: 'alerta', m: 'Microcefalia' }; 
            if (z > 2) return { c: 'alerta', m: 'Macrocefalia' }; 
            return { c: 'normal', m: 'Adequado' }; 
        } 
        if (z < -3) return { c: 'alerta', m: tipo === 'alt' ? 'Muito baixa estatura' : 'Muito baixo peso' }; 
        if (z >= -3 && z < -2) return { c: 'atencao', m: tipo === 'alt' ? 'Baixa estatura' : 'Baixo peso' }; 
        if (z >= -2 && z <= 2) return { c: 'normal', m: tipo === 'alt' ? 'Estatura adequada' : 'Peso adequado' }; 
        if (z > 2 && z <= 3) return { c: 'atencao', m: tipo === 'alt' ? 'Alta estatura' : 'Peso elevado' }; 
        if (z > 3) return { c: 'alerta', m: tipo === 'alt' ? 'Muito alta estatura' : 'Obesidade grave' }; 
        return { c: 'normal', m: 'Adequado' }; 
    }

    function drawChart(canvas, data, mes, val) { 
        if (!canvas || !data) return null;
        const curveLabels = Array.isArray(App.data?.LP) ? App.data.LP : ['P3','P10','P25','P50','P75','P90','P97'];
        const curveColors = Array.isArray(App.data?.OCOL) ? App.data.OCOL : ['#c0392b','#e67e22','#c8a200','#27ae60','#c8a200','#e67e22','#c0392b'];
        const curveWidths = Array.isArray(App.data?.OW) ? App.data.OW : [2,1.5,1.2,2.5,1.2,1.5,2];
        const curveDashes = Array.isArray(App.data?.OD) ? App.data.OD : [null,[8,4],[4,3],null,[4,3],[8,4],null];
        const dpr = window.devicePixelRatio || 1; 
        const parent = canvas.parentElement; 
        const W = Math.max(160, (parent && parent.clientWidth) || canvas.clientWidth || 160); 
        const H = Math.round(W * 0.72); 
        canvas.width = Math.round(W * dpr); 
        canvas.height = Math.round(H * dpr); 
        canvas.style.width = W + 'px'; 
        canvas.style.height = H + 'px'; 
        const ctx = canvas.getContext('2d'); 
        ctx.setTransform(1, 0, 0, 1, 0, 0); 
        ctx.clearRect(0, 0, canvas.width, canvas.height); 
        ctx.scale(dpr, dpr); 

        const PL=34, PR=30, PT=6, PB=22; 
        const CW=W-PL-PR, CH=H-PT-PB; 
        const ks = getKeys(data); 
        if (!ks.length) return null;
        const x0=ks[0], x1=ks[ks.length-1]; 
        let mn=Infinity, mx=-Infinity; 
        ks.forEach(k => data[k].forEach(v => { if(v<mn) mn=v; if(v>mx) mx=v; })); 
        const yp=(mx-mn)*0.08; 
        mn-=yp; mx+=yp; 

        const xp = v => PL+(v-x0)/(x1-x0)*CW; 
        const yp2 = v => PT+CH-(v-mn)/(mx-mn)*CH; 

        ctx.fillStyle='#fff'; 
        ctx.fillRect(0,0,W,H); 
        ctx.strokeStyle='#e8e4de'; 
        ctx.lineWidth=0.5; 
        const gridXStep = x1 > 60 ? 12 : 6;
        for (let gx=x0; gx<=x1; gx+=gridXStep) { 
            ctx.beginPath(); 
            ctx.moveTo(xp(gx),PT); 
            ctx.lineTo(xp(gx),PT+CH); 
            ctx.stroke(); 
        } 
        let ns = Math.ceil((mx-mn)/5); 
        if (!Number.isFinite(ns) || ns < 1) ns = 1;
        for (let gy=Math.ceil(mn); gy<=mx; gy+=ns) { 
            ctx.beginPath(); 
            ctx.moveTo(PL,yp2(gy)); 
            ctx.lineTo(PL+CW,yp2(gy)); 
            ctx.stroke(); 
        } 

        const bands=[ 
            {l:0,h:1,col:'rgba(192,57,43,0.09)'},
            {l:1,h:2,col:'rgba(230,126,34,0.09)'}, 
            {l:2,h:4,col:'rgba(39,174,96,0.11)'},
            {l:4,h:5,col:'rgba(230,126,34,0.09)'}, 
            {l:5,h:6,col:'rgba(192,57,43,0.09)'} 
        ]; 
        bands.forEach(b => { 
            ctx.beginPath(); 
            ks.forEach((k,i) => i===0 ? ctx.moveTo(xp(k),yp2(data[k][b.h])) : ctx.lineTo(xp(k),yp2(data[k][b.h]))); 
            for (let i=ks.length-1; i>=0; i--) ctx.lineTo(xp(ks[i]),yp2(data[ks[i]][b.l])); 
            ctx.closePath(); 
            ctx.fillStyle=b.col; 
            ctx.fill(); 
        }); 

        curveLabels.forEach((lbl,i) => { 
            ctx.beginPath(); 
            ctx.strokeStyle=curveColors[i]; 
            ctx.lineWidth=curveWidths[i]; 
            ctx.setLineDash(curveDashes[i]||[]); 
            ks.forEach((k,j) => j===0 ? ctx.moveTo(xp(k),yp2(data[k][i])) : ctx.lineTo(xp(k),yp2(data[k][i]))); 
            ctx.stroke(); 
            ctx.setLineDash([]); 
        }); 

        const lk = ks[ks.length-1]; 
        ctx.font='bold 8px system-ui,sans-serif'; 
        ctx.textAlign='left'; 
        ctx.textBaseline='middle'; 
        curveLabels.forEach((lbl,i) => { 
            ctx.fillStyle=curveColors[i]; 
            ctx.fillText(lbl, xp(lk)+3, yp2(data[lk][i])); 
        }); 

        ctx.strokeStyle='#ccc'; 
        ctx.lineWidth=1; 
        ctx.beginPath(); 
        ctx.moveTo(PL,PT); 
        ctx.lineTo(PL,PT+CH); 
        ctx.stroke(); 
        ctx.beginPath(); 
        ctx.moveTo(PL,PT+CH); 
        ctx.lineTo(PL+CW,PT+CH); 
        ctx.stroke(); 

        ctx.fillStyle='#999'; 
        ctx.font='7px system-ui,sans-serif'; 
        ctx.textAlign='center'; 
        ctx.textBaseline='top'; 
        const labelXStep = x1 > 60 ? 24 : 12;
        for (let gx=x0; gx<=x1; gx+=labelXStep) { 
            ctx.beginPath(); 
            ctx.moveTo(xp(gx),PT+CH); 
            ctx.lineTo(xp(gx),PT+CH+3); 
            ctx.stroke(); 
            ctx.fillText(x1 > 60 ? `${Math.floor(gx/12)}a` : `${gx}`, xp(gx), PT+CH+4); 
        } 
        ctx.textAlign='right'; 
        ctx.textBaseline='middle'; 
        for (let gy=Math.ceil(mn); gy<=mx; gy+=ns) { 
            ctx.beginPath(); 
            ctx.moveTo(PL-3,yp2(gy)); 
            ctx.lineTo(PL,yp2(gy)); 
            ctx.stroke(); 
            ctx.fillText(Math.round(gy*10)/10, PL-4, yp2(gy)); 
        } 

        if (val !== null && !isNaN(val)) { 
            const px = xp(Number(mes));
            const py = yp2(Number(val));
            ctx.save();
            ctx.beginPath(); 
            ctx.arc(px, py, 4.5, 0, Math.PI*2); 
            ctx.fillStyle='#111'; 
            ctx.fill(); 
            ctx.strokeStyle='#fff'; 
            ctx.lineWidth=1.3; 
            ctx.stroke(); 
            ctx.restore();
            return { pointX: px, pointY: py, width: W, height: H };
        }
        return null;
    }

    function calcularRiscoAHA(idade, sexo, pas, colTotal, hdl, dm, tabaco, estatina, antiHiper, tfg) {
        if (idade < 30 || idade > 79) return null;
        if (isNaN(tfg) || tfg <= 0) return null; 
      
        const lnIdade = Math.log(idade); const lnPAS = Math.log(pas); const lnColTotal = Math.log(colTotal); 
        const lnHDL = Math.log(hdl); const lnTFG = Math.log(Math.max(tfg, 15));
        const pasAdj = antiHiper ? pas + 10 : pas; const colAdj = estatina ? colTotal * 1.15 : colTotal; 
        const lnPASadj = Math.log(pasAdj); const lnColAdj = Math.log(colAdj);
      
        let score;
        if (sexo === 'F') { 
            const lp = -3.819975 + 0.9803*lnIdade + 0.8738*lnPASadj - 0.8738*Math.log(130) + 0.5557*lnColAdj - 0.5557*Math.log(170) - 0.7685*lnHDL + 0.7685*Math.log(55) + 0.6404*dm + 0.7823*tabaco - 0.3580*lnTFG + 0.3580*Math.log(90); 
            score = 1 - Math.pow(0.9745, Math.exp(lp));
        } else { 
            const lp = -3.057900 + 0.8673*lnIdade + 0.8018*lnPASadj - 0.8018*Math.log(130) + 0.4321*lnColAdj - 0.4321*Math.log(200) - 0.5479*lnHDL + 0.5479*Math.log(45) + 0.6749*dm + 0.8413*tabaco - 0.4139*lnTFG + 0.4139*Math.log(90); 
            score = 1 - Math.pow(0.9656, Math.exp(lp)); 
        }
        return Math.min(Math.max(score * 100, 0.1), 99.9);
    }

    function obterMetasPrevent(risco, riscoClinicoAvancado = '') {
        if (riscoClinicoAvancado === 'extremo') {
            return {
                cat: 'RISCO EXTREMO',
                catTexto: 'extremo',
                metaLDL: '40',
                metaNaoHDL: '70',
                cor: '#991b1b',
                conduta: 'Meta lipídica intensiva. Reforçar adesão ao tratamento e seguimento clínico próximo.',
            };
        }
        if (riscoClinicoAvancado === 'muito_alto') {
            return {
                cat: 'MUITO ALTO RISCO',
                catTexto: 'muito alto',
                metaLDL: '50',
                metaNaoHDL: '80',
                cor: '#b91c1c',
                conduta: 'Meta lipídica muito intensiva. Reforçar adesão ao tratamento e seguimento clínico próximo.',
            };
        }
        if (risco < 5) {
            return {
                cat: 'BAIXO',
                catTexto: 'baixo',
                metaLDL: '115',
                metaNaoHDL: '145',
                cor: '#4ade80',
                conduta: 'Priorizar mudança de estilo de vida e reavaliação periódica do risco cardiovascular.',
            };
        }
        if (risco < 20) {
            return {
                cat: 'INTERMEDIÁRIO',
                catTexto: 'intermediário',
                metaLDL: '100',
                metaNaoHDL: '130',
                cor: '#fb923c',
                conduta: 'Associar controle rigoroso de fatores de risco e considerar tratamento hipolipemiante conforme contexto clínico.',
            };
        }
        return {
            cat: 'ALTO',
            catTexto: 'alto',
            metaLDL: '70',
            metaNaoHDL: '100',
            cor: '#f87171',
            conduta: 'Controle intensivo de fatores de risco e tratamento hipolipemiante em alta prioridade.',
        };
    }

  function calcularIMCAdultoSimples(pesoKg, alturaCm) {
    const peso = Number.parseFloat(pesoKg);
    const altura = Number.parseFloat(alturaCm);
    if (Number.isNaN(peso) || Number.isNaN(altura) || altura <= 0) return null;

    const imc = peso / ((altura / 100) ** 2);
    if (imc < 18.5) return { imc: imc.toFixed(1), classif: 'Magreza', cor: '#d97706' };
    if (imc < 25) return { imc: imc.toFixed(1), classif: 'Eutrofia', cor: '#16a34a' };
    if (imc < 30) return { imc: imc.toFixed(1), classif: 'Sobrepeso', cor: '#ea580c' };
    if (imc < 35) return { imc: imc.toFixed(1), classif: 'Obesidade Grau I', cor: '#dc2626' };
    if (imc < 40) return { imc: imc.toFixed(1), classif: 'Obesidade Grau II', cor: '#b91c1c' };
    return { imc: imc.toFixed(1), classif: 'Obesidade Grau III', cor: '#991b1b' };
  }

  App.calculators = {
    getKeys,
    interp,
    calcZScore,
    getZClass,
    drawChart,
    calcularRiscoAHA,
    obterMetasPrevent,
    calcularIMCAdultoSimples,
  };
})();