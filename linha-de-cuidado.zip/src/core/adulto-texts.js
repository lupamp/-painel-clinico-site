(() => {
  const App = (window.PainelAPS = window.PainelAPS || {});

  App.adultoTexts = {
    PREVENCAO_GERAL:
      '» PREVENÇÃO GERAL: Sem comorbidades cardiometabólicas marcadas nesta avaliação. Orientado manter alimentação adequada, atividade física regular, controle de peso, evitar tabagismo e realizar rastreios oportunos conforme idade, sexo e contexto clínico.',

    getHasText({ idoso = false } = {}) {
      if (idoso) {
        return '» HIPERTENSÃO (HAS): Em geral manter < 140/90 mmHg e buscar < 130/80 mmHg conforme tolerância. Orientado reduzir sal, manter atividade física regular, evitar tabagismo, usar corretamente as medicações e retornar com medidas pressóricas quando solicitado, com individualização conforme tolerância e fragilidade.';
      }
      return '» HIPERTENSÃO (HAS): Meta pressórica preferencial < 130/80 mmHg, conforme tolerância. Orientado reduzir sal, manter atividade física regular, evitar tabagismo, usar corretamente as medicações e retornar com medidas pressóricas quando solicitado.';
    },

    getDmText({ idoso = false } = {}) {
      if (idoso) {
        return '» DIABETES (DM): Meta de HbA1c individualizada, entre < 7% e < 8%. Orientado reduzir açúcar e ultraprocessados, manter atividade física, aderir ao tratamento, cuidar dos pés e reconhecer sinais de hipoglicemia.';
      }
      return '» DIABETES (DM): Meta de HbA1c < 7%. Orientado reduzir açúcar e ultraprocessados, manter atividade física, aderir ao tratamento, cuidar dos pés e reconhecer sinais de hipoglicemia.';
    },

    getDislipTextMuitoAlto({ metaLDL, metaNaoHDL }) {
      return `» DISLIPIDEMIA: Muito alto risco cardiovascular por doença cardiovascular prévia. Meta de LDL < ${metaLDL} mg/dL e colesterol não-HDL < ${metaNaoHDL} mg/dL. Orientado reduzir gordura saturada e ultraprocessados, manter perda de peso se necessário, fazer atividade física e usar corretamente a medicação.`;
    },

    getDislipTextCalculado({ categoriaTexto, risco, metaLDL, metaNaoHDL }) {
      return `» DISLIPIDEMIA: Risco cardiovascular ${categoriaTexto} (${risco}% em 10 anos). Meta de LDL < ${metaLDL} mg/dL e colesterol não-HDL < ${metaNaoHDL} mg/dL. Orientado reduzir gordura saturada e ultraprocessados, manter perda de peso, fazer atividade física e usar corretamente a medicação.`;
    },

    // Textos para pacientes SEM dislipidemia marcada — foco preventivo, sem referência a tratamento atual
    getRiscoCVTextMuitoAlto({ metaLDL, metaNaoHDL }) {
      return `» RISCO CARDIOVASCULAR (PREVENT): Muito alto risco por doença cardiovascular prévia. Meta preventiva de LDL < ${metaLDL} mg/dL e colesterol não-HDL < ${metaNaoHDL} mg/dL. Reforçar mudança de estilo de vida, controle de fatores de risco e seguimento clínico próximo.`;
    },

    getRiscoCVTextCalculado({ categoriaTexto, risco, metaLDL, metaNaoHDL }) {
      return `» RISCO CARDIOVASCULAR (PREVENT): Risco ${categoriaTexto} (${risco}% em 10 anos, AHA 2023). Meta preventiva de LDL < ${metaLDL} mg/dL e colesterol não-HDL < ${metaNaoHDL} mg/dL. Reforçar alimentação saudável, atividade física, controle de peso e cessação de tabagismo quando aplicável.`;
    },

    DISLIP_FORA_FAIXA:
      '» DISLIPIDEMIA: PREVENT aplicável apenas de 30 a 79 anos; definir metas lipídicas conforme contexto clínico.',

    DISLIP_FALTAM_DADOS:
      '» DISLIPIDEMIA: Preencher dados necessários para cálculo do risco cardiovascular e definição das metas lipídicas.',

    getPesoText({ classif, riscoModeradoOuAlto = false } = {}) {
      if (riscoModeradoOuAlto) {
        return `» PESO / OBESIDADE: ${classif}. Meta inicial de perda ponderal de 5% e, em risco cardiovascular moderado/alto, considerar pelo menos 10%. Orientado manter alimentação adequada, reduzir ultraprocessados e manter atividade física regular.`;
      }
      return `» PESO / OBESIDADE: ${classif}. Meta inicial de perda ponderal de 5%. Orientado manter alimentação adequada, reduzir ultraprocessados e manter atividade física regular.`;
    },
  };
})();
