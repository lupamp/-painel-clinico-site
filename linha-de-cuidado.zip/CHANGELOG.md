# CHANGELOG — Painel Clínico APS

## v4.2.0 — Cálculo PREVENT para todo adulto elegível (Abril 2026)

### Novo

- **Cálculo de risco cardiovascular PREVENT agora acontece automaticamente para todo adulto elegível.**
  - Antes, o cálculo só rodava quando o checkbox "Dislipidemia" estava marcado.
  - Agora, basta ter preenchidos: idade (30-79 anos), sexo, PAS, colesterol total, HDL e TFG. O cálculo acontece mesmo sem nenhuma comorbidade marcada.
  - Quando há evento CV prévio, continua indo direto para metas agressivas (muito alto risco) sem passar pelo cálculo.
  - **Arquivo:** `src/main.js` (`obterDadosPreventAdulto`)

- **Resultado do PREVENT e metas lipídicas agora vão para o plano terapêutico em todos os casos possíveis.**
  - Quando **dislipidemia está marcada** (ou evento CV prévio): bloco com título `» DISLIPIDEMIA:` — comportamento mantido.
  - Quando **dislipidemia NÃO está marcada** e o cálculo foi possível: bloco com título `» RISCO CARDIOVASCULAR (PREVENT):` com tom preventivo (sem referência a tratamento lipídico em curso).
  - Quando o cálculo não é possível (faltam exames, fora da faixa 30-79) e não há dislip marcada: **nada é adicionado ao plano** (não gera ruído).
  - **Arquivos:** `src/main.js` (`montarCondutasAdulto`), `src/core/adulto-texts.js` (novas funções `getRiscoCVTextCalculado` e `getRiscoCVTextMuitoAlto`)

- **Flag "estatina" na fórmula PREVENT ficou mais conservadora.**
  - Antes, a flag era ativada quando `dislip || eventoCV` estava marcado.
  - Agora, só quando `dislip` está marcada. Isso reflete a intenção clínica de que "dislipidemia marcada = paciente em uso de estatina para cálculo".
  - Em pacientes sem dislip, o risco calculado reflete o cenário real (sem ajuste de +15% no CT), o que é o comportamento esperado para rastreio preventivo.
  - **Arquivo:** `src/main.js`

- **Validação de sexo adicionada ao cálculo.**
  - O cálculo não era feito quando faltava sexo, mas silenciosamente (porque a fórmula só considera M/F). Agora isso é explicitado no retorno `faltam_dados`.

---

## v4.1.0 — Refinamentos Clínicos de Puericultura (Abril 2026)

### Novo

- **Plano terapêutico de Puericultura/Adolescentes agora mostra apenas o parâmetro antropométrico.**
  - O texto de desenvolvimento, alimentação e orientações gerais (que vem do painel "Consulta Criança") foi **removido do plano**.
  - A seção `》AVALIAÇÃO ANTROPOMÉTRICA` continua indo normalmente para o campo **Avaliação** do prontuário.
  - O plano agora contém apenas: planos derivados do Z-Score (magreza/sobrepeso/baixa estatura/alteração PC) ou a mensagem de eutrofia quando todos os parâmetros estão adequados.
  - Se o profissional preencher só a idade da pueri (sem peso/altura), o plano fica vazio.
  - **Arquivo:** `src/main.js`

- **Avaliação do Estágio de Maturação Sexual (0301010285) automática para ≥ 10 anos.**
  - Ao clicar em "👶 Puericultura (Médico)", o código `0301010285` é adicionado automaticamente à lista de procedimentos quando a idade do paciente é ≥ 10 anos completos.
  - O modal de confirmação mostra o label "Puericultura (Médico) + Maturação Sexual" quando o acréscimo ocorre.
  - Não afeta o perfil de Enfermagem.
  - **Arquivo:** `src/main.js` (função `montarPayloadPueriMedico`)

- **Marcação por texto para Consulta Médica em Atenção Primária (0301010064).**
  - O ISF do SISS Online lista este código com descrições variáveis, então a marcação por número puro pode falhar.
  - Introduzido prefixo convencional `*` nos procedimentos: quando o item começa com `*`, a extensão busca a linha pelo **texto** (normalizado — sem acentos, caixa alta), não pelo número.
  - Aplicado em: Puericultura Médica (`*0301010064 - CONSULTA MEDICA EM ATENÇÃO PRIMÁRIA`).
  - O prefixo `*` também já estava em uso para HAS e DM médicas; agora o comportamento funciona de verdade.
  - **Arquivos:** `src/bridge/frame-bridge.js`, `src/core/constants.js`

---

## v4.0.0 — Correções de Segurança e Gargalos (Abril 2026)

Versão com todas as correções identificadas na auditoria técnica.

### CRÍTICO — Corrigidos

- **S01 — postMessage com targetOrigin fixo**
  - `broadcastMessage()` e `postToTop()` agora usam `'https://sissonline.com.br'` em vez de `'*'`.
  - `enviarParaFrames()` não sobrescreve mais a origin com `'*'`.
  - **Arquivos:** `utils.js`, `frame-bridge.js`, `main.js`

- **S02 — Validação de origem corrigida**
  - `isTrustedSissonMessage()` não aceita mais `event.origin === 'null'`.
  - Agora valida contra lista explícita de origens confiáveis (`TRUSTED_ORIGINS`).
  - **Arquivo:** `utils.js`

- **S03 — innerHTML substituído por textContent / escapeHtml**
  - Criada função `escapeHtml()` em `utils.js`.
  - Todos os pontos que inseriam dados dinâmicos do prontuário via `innerHTML` agora usam `escapeHtml()` ou `textContent`.
  - Labels de botões trocados de `innerHTML` para `textContent`.
  - **Arquivos:** `utils.js`, `main.js`

### ALTO — Corrigidos

- **S04 — Modal de confirmação antes de escrita no prontuário**
  - Criada função `confirmarAcao()` que exibe overlay modal com preview do texto.
  - Wrappers `enviarCondutaComConfirmacao()` e `enviarISFComConfirmacao()` adicionados.
  - **Todos** os botões de exportação e lançamento de procedimentos agora passam por confirmação.
  - **Arquivo:** `main.js`

- **S05 — Content Security Policy adicionada**
  - `manifest.json` agora declara: `"script-src 'self'; object-src 'none'"`.
  - **Arquivo:** `manifest.json`

- **S06 — Permissão storage adicionada**
  - `manifest.json` agora inclui `"permissions": ["storage"]` para suportar logging.
  - *Nota: a separação de scripts em top-only/frame-only requer refatoração mais profunda; main.js já faz `if (window !== window.top) return;` como proteção.*
  - **Arquivo:** `manifest.json`

- **S07 — Sistema de auditoria implementado**
  - Função `registrarAuditoria()` grava logs em `chrome.storage.local` com timestamp, ação e resumo.
  - Mantém até 500 entradas em rotação.
  - Logging ativado em: inicialização da extensão, inserção de conduta, lançamento de procedimentos, healthcheck.
  - **Arquivos:** `utils.js`, `frame-bridge.js`, `main.js`

### MÉDIO — Corrigidos

- **G01 — Namespace protegido**
  - `App.constants`, `App.constants.IDS`, `App.constants.SELECTORS` e `App.constants.MESSAGE_TYPES` agora são congelados com `Object.freeze()`.
  - **Arquivo:** `constants.js`

- **G03 — Funções duplicadas removidas**
  - `buscarElemento()` local em `cc-auto` substituída por `findElementDeep()` de `utils.js`.
  - `getValor()` local substituída por `getFieldValue()` de `utils.js`.
  - `parseValorBR()` local substituída por `parseBRNumber()` de `utils.js`.
  - **Arquivo:** `main.js`

- **G04 — Healthcheck de seletores no boot**
  - Função `verificarSeletoresCriticos()` criada em `utils.js`.
  - Executada 3s após boot; registra alerta no log de auditoria se seletores não forem encontrados.
  - **Arquivos:** `utils.js`, `main.js`

### BAIXO — Melhorias

- **I01 — Versão atualizada para 4.0.0** com descrição indicando as correções de segurança.

### Pendente para próximas versões

- **G02** — Substituir `setTimeout` por `MutationObserver` no `processarLancamentoISF()`.
- **I02** — Criar suite de testes unitários para `calculators.js`.
- **I03** — Avaliar lazy-loading do `data.js` para reduzir uso de memória em multi-frame.
